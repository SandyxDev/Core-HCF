<?php

namespace venity\entities;

use venity\Loader;

use venity\entities\ZombieBard;
use venity\entities\FakeVillager;
use pocketmine\entity\EntityDataHelper;

use venity\entities\tiles\{MonsterTileSpawner};

use venity\entities\spawnable\{Cow, Enderman, Villager, Pig, Creeper, Turtle, Horse};

use pocketmine\entity\{Entity,EntityFactory};
use pocketmine\tile\Tile;

class Entitys {
	
	/**
	 * @return void
	 */
	public static function init() : void {
		/*
		(new EntityFactory)->registerEntity(Cow::class, true, ["Cow"]);
		(new EntityFactory)->registerEntity(Enderman::class, true, ["Enderman"]);
		(new EntityFactory)->registerEntity(Villager::class, true, ["Villager"]);
		(new EntityFactory)->registerEntity(Pig::class, true, ["Pig"]);
		(new EntityFactory)->registerEntity(Creeper::class, true, ["Creeper"]);
		(new EntityFactory)->registerEntity(Turtle::class, true, ["Turtle"]);
		(new EntityFactory)->registerEntity(Horse::class, true, ["Horse"]);
        (new EntityFactory)->registerEntity(Egg::class, true, ["Egg"]);
        (new EntityFactory)->registerEntity(ZombieBard::class, true);
        (new EntityFactory)->registerEntity(FakeVillager::class, true);
		(new EntityFactory)->registerEntity(SplashPotion::class, true, ["SplashPotion"]);
		(new EntityFactory)->registerEntity(FishingHook::class, true, ["FishingHook"]);
		*/
		//Tile::register(MonsterTileSpawner::class);
	}
	
	/**
	 * @return Array[]
	 */
	public static function getEntitysType() : Array {
		return Loader::getDefaultConfig("Entitys");
	}
}

?>