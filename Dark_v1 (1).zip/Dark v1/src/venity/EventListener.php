<?php

namespace venity;

use venity\{Loader, Factions};
use venity\player\{Player, PlayerBase};
 

use venity\Task\asynctask\{LoadPlayerData, SavePlayerData};

use venity\Task\Scoreboard;

use pocketmine\event\Listener;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TE;
use pocketmine\world\biome\Biome;

use pocketmine\event\level\ChunkLoadEvent;
use pocketmine\event\player\{PlayerJoinEvent, PlayerQuitEvent, PlayerChatEvent, PlayerMoveEvent, PlayerInteractEvent};
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\entity\EntityLevelChangeEvent;

use pocketmine\network\mcpe\protocol\LevelEventPacket;

class EventListener implements Listener {

    /**
     * EventListener Constructor.
     */
    public function __construct(){
		
    }
    
    /**
     * @param PlayerCreationEvent $event
     * @return void
     */
    public function onPlayerCreationEvent(PlayerCreationEvent $event) : void {
        $event->setPlayerClass(Player::class, true);
    }

    /**
     * @param PlayerJoinEvent $event
     * @return void
     */
    public function onPlayerJoinEvent(PlayerJoinEvent $event) : void {
        $player = $event->getPlayer();
        $event->setJoinMessage(TE::GRAY."[".TE::GREEN."+".TE::GRAY."] ".TE::GREEN.$player->getName().TE::GRAY." Entro a Dark");
        
        
        
        
        PlayerBase::create($player->getName());
		Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new Scoreboard($player), 20);
        Loader::getInstance()->getServer()->getAsyncPool()->submitTask(new LoadPlayerData($player->getName(), $player->getUniqueId()->toString(), Loader::getDefaultConfig("MySQL")["hostname"], Loader::getDefaultConfig("MySQL")["username"], Loader::getDefaultConfig("MySQL")["password"], Loader::getDefaultConfig("MySQL")["database"], Loader::getDefaultConfig("MySQL")["port"]));
    }

    /**
     * @param PlayerQuitEvent $event
     * @return void
     */
    public function onPlayerQuitEvent(PlayerQuitEvent $event) : void {
        $player = $event->getPlayer();
		$event->setQuitMessage(TE::GRAY."[".TE::RED."-".TE::GRAY."] ".TE::RED.$player->getName().TE::GRAY."Salio de Dark");

        Loader::getInstance()->getServer()->getAsyncPool()->submitTask(new SavePlayerData($player->getNetworkSession()->getIp(), Factions::inFaction($player->getName()) ? Factions::getFaction($player->getName()) : "This player not have faction", Loader::getDefaultConfig("MySQL")["hostname"], Loader::getDefaultConfig("MySQL")["username"], Loader::getDefaultConfig("MySQL")["password"], Loader::getDefaultConfig("MySQL")["database"], Loader::getDefaultConfig("MySQL")["port"]));         if($player instanceof Player){             $player->removePermissionsPlayer();
		}
	}
	
	/**
     * @param EntityLevelChangeEvent $event
     * @return void
     */
	/*
	Dont Working Class Not Found
	public function onEntityLevelChangeEvent(EntityLevelChangeEvent $event) : void {
		$player = $event->getEntity();
		$player->showCoordinates();
	}
    */
    /**
     * @param PlayerChatEvent $event
     * @return void
     */
    public function onPlayerChatEvent(PlayerChatEvent $event) : void {
    	$player = $event->getPlayer();
    	$format = null;
    	if($player->getRank() === null||$player->getRank() === "Guest"){
            $format = TE::GRAY."[".TE::GREEN."Guest".TE::GRAY."] ".TE::GRAY.$player->getName().TE::WHITE;
        }
    	if($player->getRank() === "Owner"){
    		$format = TE::DARK_GRAY."[".TE::DARK_RED."Owner".TE::DARK_GRAY."] ".TE::DARK_RED.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Co-Owner"){
    		$format = TE::DARK_GRAY."[".TE::RED."Co-Owner".TE::DARK_GRAY."] ".TE::RED.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Admin"){
    		$format = TE::DARK_GRAY."[".TE::GREEN."Admin".TE::DARK_GRAY."] ".TE::GREEN.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Creator"){
    		$format = TE::DARK_GRAY."[".TE::DARK_PURPLE."§6Creator".TE::DARK_GRAY."] ".TE::DARK_PURPLE.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Mod"){
    		$format = TE::DARK_GRAY."[".TE::LIGHT_PURPLE."Mod".TE::DARK_GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Coordinator"){
    		$format = TE::DARK_GRAY."[".TE::LIGHT_PURPLE."Coordinator".TE::DARK_GRAY."] ".TE::DARK_AQUA.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Sr-Admin"){
    		$format = TE::DARK_GRAY."[".TE::AQUA."Sr-Admin".TE::DARK_GRAY."] ".TE::AQUA.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Trial-Mod"){
    		$format = TE::DARK_GRAY."[".TE::DARK_AQUA."Trial-Mod".TE::DARK_GRAY."] ".TE::DARK_AQUA.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Trainee"){
    		$format = TE::DARK_GRAY."[".TE::YELLOW."Trainee".TE::DARK_GRAY."] ".TE::YELLOW.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Configurador"){
    		$format = TE::DARK_GRAY."[".TE::YELLOW."§5Configurador".TE::DARK_GRAY."] ".TE::YELLOW.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Donator"){
    		$format = TE::DARK_GRAY."[".TE::RED."Donator" .TE::DARK_GRAY."] ".TE::RED.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Murder"){
    		$format = TE::DARK_GRAY."[".TE::GOLD."§gMurder".TE::DARK_GRAY."] ".TE::YELLOW.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Dragon"){
    		$format = TE::DARK_GRAY."[".TE::DARK_PURPLE."§cDragon".TE::RESET.TE::DARK_GRAY."] ".TE::DARK_RED.$player->getName().TE::WHITE;
		}
		if($player->getRank() === "Mytical"){
    		$format = TE::DARK_GRAY."[".TE::AQUA."§9Mytical".TE::RESET.TE::DARK_GRAY."] ".TE::GOLD.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "NitroBooster"){
    		$format = TE::DARK_GRAY."[".TE::LIGHT_PURPLE."NitroBooster".TE::RESET.TE::DARK_GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
    	}
        if($player->getRank() === "PlatForm-Admin"){
            $format = TE::DARK_GRAY."[".TE::LIGHT_PURPLE."PlatForm.Admn".TE::RESET.TE::DARK_GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
        }
    	if($player->getRank() === "Mistery"){
    		$format = TE::DARK_GRAY."[".TE::DARK_RED."§bMistery".TE::DARK_GRAY."] ".TE::DARK_AQUA.$player->getName().TE::WHITE;
    	}
     if($player->getRank() === "Founder"){
            $format = TE::DARK_GRAY."[".TE::DARK_RED."Founder".TE::DARK_GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
        }
    	if($player->getRank() === "Partner"){
    		$format = TE::DARK_GRAY."[".TE::OBFUSCATED.TE::YELLOW."!!".TE::RESET.TE::AQUA.TE::BOLD."Partner".TE::RESET.TE::OBFUSCATED.TE::YELLOW."!!".TE::RESET.TE::DARK_GRAY."] ".TE::AQUA.$player->getName().TE::WHITE;
    	}
        if($player->getRank() === "TikTok"){
    		$format = TE::DARK_GRAY."[".TE::OBFUSCATED.TE::YELLOW."!!".TE::RESET.TE::WHITE."Tik".TE::BLACK."Tok".TE::RESET.TE::OBFUSCATED.TE::YELLOW."!!".TE::RESET.TE::DARK_GRAY."] ".TE::AQUA.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "MiniYT"){
    		$format = TE::DARK_GRAY."[".TE::RED."Mini".TE::WHITE."YT".TE::DARK_GRAY."] ".TE::RED.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Youtuber"){
    		$format = TE::DARK_GRAY."[".TE::DARK_RED."You".TE:: DARK_RED."uber".TE::DARK_GRAY."] ".TE::DARK_RED.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Famous"){
    		$format = TE::DARK_GRAY."[".TE::LIGHT_PURPLE.TE::BOLD."Famous".TE::RESET.TE::DARK_GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
    	}
    	if($player->getRank() === "Streamer"){
    		$format = TE::DARK_GRAY."[".TE::LIGHT_PURPLE."Twitch".TE::DARK_GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
    	}
        if($player->getRank() === "Support"){
            $format = TE::DARK_GRAY."[".TE::LIGHT_PURPLE."Twitch".TE::DARK_GRAY."] ".TE::LIGHT_PURPLE.$player->getName().TE::WHITE;
        }
    	if(Factions::inFaction($player->getName())){
			$factionName = Factions::getFaction($player->getName());
			$event->setFormat(TE::GOLD."[".TE::RED.$factionName.TE::GOLD."]".TE::RESET.$format." » ".$event->getMessage());
		}else{
			$event->setFormat($format." : ".$event->getMessage());
		}
	}
}

?>
