<?php

namespace venity\utils;

use venity\player\Player;
use venity\API\System;
use pocketmine\network\mcpe\convert\RuntimeBlockMapping;
use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\network\mcpe\protocol\types\BlockPosition;
use pocketmine\network\mcpe\protocol\BlockActorDataPacket;
use pocketmine\network\mcpe\protocol\UpdateBlockPacket;
use pocketmine\block\BlockFactory;
class Tower {

    /**
     * @param Vector3 $position
     * @param Player $player
     * @param Block $block
     * @return void
     */
    public static function create(Block | Vector3 $position, Player $player, Block $block) : void {
        if($position instanceof Vector3){
			for($y = $position->getFloorY() + 1; $y <= $position->getFloorY() + 20; $y++){
				$blockMapping = RuntimeBlockMapping::getInstance();
            	$x = $position->getFloorX();
            	$z = $position->getFloorZ();
            	$blockPosition = new BlockPosition($x, $y, $z);
            
            	$pk = UpdateBlockPacket::create($blockPosition ,$blockMapping->toRuntimeId($block->getFullId()), UpdateBlockPacket::FLAG_NETWORK, UpdateBlockPacket::DATA_LAYER_NORMAL);
            	$player->getNetworkSession()->sendDataPacket($pk);
        }
		return;
        }
        for($y = $position->getPosition()->getFloorY() + 1; $y <= $position->getPosition()->getFloorY() + 20; $y++){
			$blockMapping = RuntimeBlockMapping::getInstance();
            $x = $position->getPosition()->getFloorX();
            $z = $position->getPosition()->getFloorZ();
            $blockPosition = new BlockPosition($x, $y, $z);
            
            $pk = UpdateBlockPacket::create($blockPosition ,$blockMapping->toRuntimeId($block->getFullId()), UpdateBlockPacket::FLAG_NETWORK, UpdateBlockPacket::DATA_LAYER_NORMAL);
            $player->getNetworkSession()->sendDataPacket($pk);
        }
    }
    
    /**
     * @param Player $player
     * @param Int $id
     * @return void
     */
    public static function delete(Player $player, Int $id) : void {
        if(System::isPosition($player, $id)){
            $position = Translator::arrayToVector3(System::$cache[$player->getName()]["position".$id]);
            $air = (new BlockFactory)->get(0, 0);
      		self::create($position, $player, $air);
        }
    }
}

?>