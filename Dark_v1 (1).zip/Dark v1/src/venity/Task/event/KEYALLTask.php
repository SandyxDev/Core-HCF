<?php

namespace venity\Task\event;

use venity\Loader;
use venity\player\Player;

use venity\listeners\event\KEYALL;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class KEYALLTask extends Task {
	
	/**
	 * KEYALLTask Constructor.
	 * @param Int $time
	 */
	public function __construct(Int $time = 60){
		KEYALL::setTime($time);
	}
	
	/**
	 * @param Int $currentTick
	 * @return void
	 */
	public function onRun() : void {
		if(!KEYALL::isEnable()){
			$this->getHandler()->cancel();
			return;
		}
		if(KEYALL::getTime() === 0){
			KEYALL::setEnable(false);
			$this->getHandler()->cancel();
		}else{
			KEYALL::setTime(KEYALL::getTime() - 1);
		}
	}
}

?>