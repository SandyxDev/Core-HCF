<?php

namespace venity\Task\event;

use venity\Loader;
use venity\player\Player;

use venity\listeners\event\FFA;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class FFATask extends Task {
	
	/**
	 * FFATask Constructor.
	 * @param Int $time
	 */
	public function __construct(Int $time = 60){
		FFA::setTime($time);
	}
	
	/**
	 * @param Int $currentTick
	 * @return void
	 */
	public function onRun() : void {
		if(!FFA::isEnable()){
			$this->getHandler()->cancel();
			return;
		}
		if(FFA::getTime() === 0){
			FFA::setEnable(false);
			$this->getHandler()->cancel();
		}else{
			FFA::setTime(FFA::getTime() - 1);
		}
	}
}

?>