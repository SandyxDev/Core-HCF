<?php

namespace venity\Task\event;

use venity\Loader;
use venity\player\Player;

use venity\listeners\event\KEYALLOP;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class KEYALLOPTask extends Task {
	
	/**
	 * KEYALLTask Constructor.
	 * @param Int $time
	 */
	public function __construct(Int $time = 60){
		KEYALLOP::setTime($time);
	}
	
	/**
	 * @param Int $currentTick
	 * @return void
	 */
	public function onRun() : void {
		if(!KEYALLOP::isEnable()){
			$this->getHandler()->cancel();
			return;
		}
		if(KEYALLOP::getTime() === 0){
			KEYALLOP::setEnable(false);
			$this->getHandler()->cancel();
		}else{
			KEYALLOP::setTime(KEYALLOP::getTime() - 1);
		}
	}
}

?>