<?php

namespace venity\Task\event;

use venity\{Loader, Factions};
use venity\player\{Player, PlayerBase};

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class InvincibilityTask extends Task {
	
	/** @var Player */
	protected $player;
	
	/**
	 * InvincibilityTask Constructor.
	 * @param Player $player
	 */
	public function __construct(Player $player){
		$this->player = $player;
		$player->setInvincibilityTime(PlayerBase::getData($player->getName())->get("pvp_time"));
	}
	
	/**
	 * @param Int $currentTick
	 * @return void
	 */
	public function onRun() : void {
		$player = $this->player;
		if(!$player->isOnline()){
			$this->getHandler()->cancel();
			return;
		}
		if(!$player->isInvincibility()){
        	$this->getHandler()->cancel();
        	return;
        }
		if(!PlayerBase::isData($player->getName(), "pvp_time")){
			$this->getHandler()->cancel();
			return;	
		}
		if($player->getInvincibilityTime() === 0){
			PlayerBase::removeData($player->getName(), "pvp_time");
			$player->setInvincibility(false);
			$this->getHandler()->cancel();
		}else{
			if(Factions::isSpawnRegion($player)) return;
			$player->setInvincibilityTime($player->getInvincibilityTime() - 1);
		}
	}
}

?>