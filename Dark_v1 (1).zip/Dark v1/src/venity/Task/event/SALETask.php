<?php

namespace venity\Task\event;

use venity\Loader;
use venity\player\Player;

use venity\listeners\event\SALE;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class SALETask extends Task {
	
	/**
	 * SALETask Constructor.
	 * @param Int $time
	 */
	public function __construct(Int $time = 60){
		SALE::setTime($time);
	}
	
	/**
	 * @param Int $currentTick
	 * @return void
	 */
	public function onRun() : void {
		if(!SALE::isEnable()){
			$this->getHandler()->cancel();
			return;
		}
		if(SALE::getTime() === 0){
			SALE::setEnable(false);
			$this->getHandler()->cancel();
		}else{
			SALE::setTime(SALE::getTime() - 1);
		}
	}
}

?>