<?php

namespace venity\Task;

use venity\Loader;
use venity\player\Player;

use venity\listeners\interact\Gapple;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class GappleTask extends Task {
	
	/** @var Player */
	protected $player;
	
	/**
	 * GappleTask Constructor.
	 * @param String $player|null
	 */
	public function __construct(?String $player){
		$this->player = $player;
	}
	
	/**
	 * @param Int $currentTick
	 */
	public function onRun(){
		$playerName = $this->player;
		if(Loader::$appleenchanted[$playerName]["time"] < time()){
			Gapple::removeGappleCooldown($playerName);
			$this->getHandler()->cancel();
		}
	}
}

?>