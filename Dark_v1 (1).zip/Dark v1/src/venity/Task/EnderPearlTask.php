<?php

namespace venity\Task;

use venity\Loader;
use venity\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class EnderPearlTask extends Task {

    /** @var Player */
    protected $player;

    /**
     * EnderPearlTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setEnderPearlTime(Loader::getDefaultConfig("Cooldowns")["EnderPearl"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $player = $this->player;
        if(!$player->isOnline()){
        	$this->getHandler()->cancel();
        	return;
        }
        if($player->isEnderPearl()){
            if($player->getEnderPearlTime() === 0){
                $player->setEnderPearl(false);
                $this->getHandler()->cancel();
            }else{
                $player->setEnderPearlTime($player->getEnderPearlTime() - 1);
            }
        }else{
            $this->getHandler()->cancel();
            return;
        }
    }
}

?>