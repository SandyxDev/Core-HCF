<?php


namespace venity\Task\specials;

use venity\Loader;
use venity\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class PotionCounterTask extends Task {

    /**
     * PotionCounterTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setPotionCounterTime(Loader::getDefaultConfig("Cooldowns")["PotionCounter"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $player = $this->player;
        if(!$player->isOnline()){
            $this->getHandler()->cancel();
            return;
        }
        if($player->getPotionCounterTime() === 0){
            $player->setPotionCounter(false);
            $this->getHandler()->cancel();
        }else{
            $player->setPotionCounterTime($player->getPotionCounterTime() - 1);
        }
    }
}