<?php

namespace venity\Task\specials;

use venity\Loader;
use venity\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class SecondChanceTask extends Task {

    /** @var Player */
    protected $player;

    /**
     * StrengthTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setSecondChanceTime(Loader::getDefaultConfig("Cooldowns")["SecondChance"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $player = $this->player;
        if(!$player->isOnline()){
            $this->getHandler()->cancel();
            return;
        }
        if($player->getSecondChanceTime() === 0){
            $player->setSecondChance(false);
            $this->getHandler()->cancel();
        }else{
            $player->setSecondChanceTime($player->getSecondChanceTime() - 1);
        }
    }
}

?>