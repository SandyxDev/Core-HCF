<?php

namespace venity\Task\specials;

use venity\Loader;
use venity\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class RagebrickTask extends Task {

    /** @var Player */
    protected $player;

    /**
     * StrengthTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setRagebrickTime(Loader::getDefaultConfig("Cooldowns")["Ragebrick"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $player = $this->player;
        if(!$player->isOnline()){
            $this->getHandler()->cancel();
            return;
        }
        if($player->getRagebrickTime() === 0){
            $player->setRagebrick(false);
            $this->getHandler()->cancel();
        }else{
            $player->setRagebrickTime($player->getRagebrickTime() - 1);
        }
    }
}

?>