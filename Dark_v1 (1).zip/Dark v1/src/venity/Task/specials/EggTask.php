<?php

namespace venity\Task\specials;

use venity\Loader;
use venity\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class EggTask extends Task {

    /** @var Player */
    protected $player;

    /**
     * EggTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setEggTime(Loader::getDefaultConfig("Cooldowns")["EggPort"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $player = $this->player;
        if(!$player->isOnline()){
            $this->getHandler()->cancel();
            return;
        }
        if($player->getEggTime() === 0){
            $player->setEgg(false);
            $this->getHandler()->cancel();
        }else{
            $player->setEggTime($player->getEggTime() - 1);
        }
    }
}

?>