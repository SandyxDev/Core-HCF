<?php

namespace venity\Task\specials;

use venity\Loader;
use venity\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class MedkitTask extends Task {

    /** @var Player */
    protected $player;

    /**
     * MedkitTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setMedkitTime(Loader::getDefaultConfig("Cooldowns")["Medkit"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $player = $this->player;
        if(!$player->isOnline()){
            $this->getHandler()->cancel();
            return;
        }
        if($player->getMedkitTime() === 0){
            $player->setMedkit(false);
            $this->getHandler()->cancel();
        }else{
            $player->setMedkitTime($player->getMedkitTime() - 1);
        }
    }
}

?>