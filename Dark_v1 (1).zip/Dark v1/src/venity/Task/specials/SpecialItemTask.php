<?php

namespace venity\Task\specials;

use venity\Loader;
use venity\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class SpecialItemTask extends Task {

    /** @var Player */
    protected $player;

    /**
     * SpecialItemTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setSpecialItemTime(Loader::getDefaultConfig("Cooldowns")["SpecialItem"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $player = $this->player;
        if(!$player->isOnline()){
            $this->getHandler()->cancel();
            return;
        }
        if($player->getSpecialItemTime() === 0){
            $player->setSpecialItem(false);
            $this->getHandler()->cancel();
        }else{
            $player->setSpecialItemTime($player->getSpecialItemTime() - 1);
        }
    }
}

?>