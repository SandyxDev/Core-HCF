<?php

namespace venity\Task\specials;

use venity\Loader;
use venity\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class StrengthTask extends Task {

    /** @var Player */
    protected $player;

    /**
     * StrengthTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setStrengthTime(Loader::getDefaultConfig("Cooldowns")["Strength"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $player = $this->player;
        if(!$player->isOnline()){
            $this->getHandler()->cancel();
            return;
        }
        if($player->getStrengthTime() === 0){
            $player->setStrength(false);
            $this->getHandler()->cancel();
        }else{
            $player->setStrengthTime($player->getStrengthTime() - 1);
        }
    }
}

?>