<?php

namespace venity\Task;

use venity\Loader;
use venity\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class ArcherTagTask extends Task {

    /** @var Player */
    protected $player;

    /**
     * ArcherTagTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setArcherTagTime(Loader::getDefaultConfig("Cooldowns")["ArcherTag"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $player = $this->player;
        if(!$player->isOnline()){
        	$this->getHandler()->cancel();
        	return;
        }
        if(!$player->isArcherTag()){
        	$this->getHandler()->cancel();
        	return;
        }
        if($player->getArcherTagTime() === 0){
            $player->setArcherTag(false);
            $this->getHandler()->cancel();
        }else{
            $player->setArcherTagTime($player->getArcherTagTime() - 1);
        }
    }
}

?>