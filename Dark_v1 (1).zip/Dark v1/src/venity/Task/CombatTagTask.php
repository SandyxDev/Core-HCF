<?php

namespace venity\Task;

use venity\Loader;
use venity\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class CombatTagTask extends Task {

    /** @var Player */
    protected $player;

    /**
     * CombatTagTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setCombatTagTime(Loader::getDefaultConfig("Cooldowns")["CombatTag"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $player = $this->player;
        if(!$player->isOnline()){
        	$this->getHandler()->cancel();
        	return;
        }
        if(!$player->isCombatTag()){
        	$this->getHandler()->cancel();
        	return;
        }
        if($player->getCombatTagTime() === 0){
            $player->setCombatTag(false);
            $this->getHandler()->cancel();
        }else{
            $player->setCombatTagTime($player->getCombatTagTime() - 1);
        }
    }
}

?>