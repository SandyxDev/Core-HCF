<?php

namespace venity\Task;

use venity\{Loader, Factions};
use venity\player\Player;

use pocketmine\item\{Item, ItemIds};
use pocketmine\item\ItemFactory;
use pocketmine\entity\effect\{Effect, EffectInstance};

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class BardTask extends Task {

    /**
     * BardTask Constructor.
     */
    public function __construct(){

    }
    
    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        foreach(Loader::getInstance()->getServer()->getOnlinePlayers() as $player){
        	$player->checkClass();
            if($player->isBardClass() && $player->getBardEnergy() < 120){
				$player->setBardEnergy($player->getBardEnergy() + 1);
	            if(Factions::inFaction($player->getName())){
	                switch($player->getInventory()->getItemInHand()->getId()){
	                    case ItemIds::SUGAR:
	                    	if(Factions::isSpawnRegion($player)) return;
	                        foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
	                            $online = Loader::getInstance()->getServer()->getPlayerExact($value);
	                            if($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 250){
	                                $online->addEffect(new EffectInstance(Player::getEffectName('speed'), 20 * 10, 1));
	                            }
	                        }
	                    break;
	                    case ItemIds::IRON_INGOT:
	                    	if(Factions::isSpawnRegion($player)) return;
	                        foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
	                            $online = Loader::getInstance()->getServer()->getPlayerExact($value);
	                            if($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 250){
	                                $online->addEffect(new EffectInstance(Player::getEffectName('resistance'), 20 * 10, 1));
	                            }
	                        }
	                    break;
	                    case ItemIds::BLAZE_POWDER:
	                    	if(Factions::isSpawnRegion($player)) return;
	                        foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
	                            $online = Loader::getInstance()->getServer()->getPlayerExact($value);
	                            if($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 250){
	                                $online->addEffect(new EffectInstance(Player::getEffectName('strength'), 20 * 10, 0));
	                            }
	                        }
	                    break;
	                    case ItemIds::GHAST_TEAR:
	                    	if(Factions::isSpawnRegion($player)) return;
	                        foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
	                            $online = Loader::getInstance()->getServer()->getPlayerExact($value);
	                            if($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 250){
	                                $online->addEffect(new EffectInstance(Player::getEffectName('regeneration'), 20 * 10, 1));
	                            }
	                        }
	                    break;
	                    case ItemIds::FEATHER:
	                    	if(Factions::isSpawnRegion($player)) return;
	                        foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
	                            $online = Loader::getInstance()->getServer()->getPlayerExact($value);
	                            if($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 250){
	                                $online->addEffect(new EffectInstance(Player::getEffectName('jump_boost'), 20 * 10, 1));
	                            }
	                        }
	                    break;
	                    case ItemIds::DYE:
	                    	if(Factions::isSpawnRegion($player)) return;
	                        foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
	                            $online = Loader::getInstance()->getServer()->getPlayerExact($value);
	                            if($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 250){
	                                $online->addEffect(new EffectInstance(Player::getEffectName('invisibility'), 20 * 10, 0));
	                            }
	                        }
	                    break;
	                    case ItemIds::MAGMA_CREAM:
	                    	if(Factions::isSpawnRegion($player)) return;
	                        foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
	                            $online = Loader::getInstance()->getServer()->getPlayerExact($value);
	                            if($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 250){
	                                $online->addEffect(new EffectInstance(Player::getEffectName('fire'), 20 * 10, 1));
	                            }
	                        }
	                    break;
	                }
	            }
	        }
	    }
	}
}

?>