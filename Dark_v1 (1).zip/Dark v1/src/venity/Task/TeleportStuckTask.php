<?php

namespace venity\Task;

use venity\{Loader, Factions};
use venity\player\Player;

use pocketmine\math\Vector3;
use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class TeleportStuckTask extends Task {

    /** @var Player */
    protected $player;

    /**
     * TeleportStuckTask Constructor.
     * @param Player $player
     */
    public function __construct(Player $player){
        $this->player = $player;
        $player->setTeleportingStuckTime(Loader::getDefaultConfig("Cooldowns")["Stuck"]);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $player = $this->player;
        if(!$player->isOnline()){
        	$this->getHandler()->cancel();
        	return;
        }
        if(!$player->isTeleportingStuck()){
        	$this->getHandler()->cancel();
        	return;
        }
        if($player->getTeleportingStuckTime() === 0){
            if($player->getPosition()->getY() < 40){
            	$player->setTeleportingStuck(false);
            	$player->teleport(new Vector3($player->getPosition()->getX() + 20, 75, $player->getPosition()->getZ() + 20, $player->getPosition()->getWorld()));
        	    $this->getHandler()->cancel();
        	}
        	if($player->getPosition()->getY() < 20){
        		$player->setTeleportingStuck(false);
        		$player->teleport(new Vector3($player->getPosition()->getX() + 20, 75, $player->getPosition()->getZ() + 20, $player->getPosition()->getWorld()));
        	    $this->getHandler()->cancel();
        	}
        	if($player->getPosition()->getY() < 10){
        		$player->setTeleportingStuck(false);
        		$player->teleport(new Vector3($player->getPosition()->getX() + 20, 75, $player->getPosition()->getZ() + 20, $player->getPosition()->getWorld()));
        	    $this->getHandler()->cancel();
        	}
        	if($player->getPosition()->getY() > 70){
        		$player->setTeleportingStuck(false);
        		$player->teleport(new Vector3($player->getPosition()->getX() + 20, 75, $player->getPosition()->getZ() + 20, $player->getPosition()->getWorld()));
        	    $this->getHandler()->cancel();
        	}else{
        		$player->setTeleportingStuck(false);
        		$player->teleport(new Vector3($player->getPosition()->getX() + 20, 75, $player->getPosition()->getZ() + 20, $player->getPosition()->getWorld()));
        	    $this->getHandler()->cancel();
        	}
        }else{
            $player->setTeleportingStuckTime($player->getTeleportingStuckTime() - 1);
        }
    }
}

?>
