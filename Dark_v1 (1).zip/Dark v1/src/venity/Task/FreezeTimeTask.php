<?php

namespace venity\Task;

use venity\{Loader, Factions};
use venity\player\Player;

use pocketmine\scheduler\Task;
use pocketmine\utils\TextFormat as TE;

class FreezeTimeTask extends Task {

    /** @var String */
    protected $factionName;

    /**
     * FreezeTimeTask Constructor.
     * @param String $factionName
     * @param Int $time
     */
    public function __construct(String $factionName, Int $time = 1800){
        $this->factionName = $factionName;
        Factions::setFreezeTime($factionName, $time);
    }

    /**
     * @param Int $currentTick
     * @return void
     */
    public function onRun() : void {
        $factionName = $this->factionName;
        if(!Factions::isFreezeTime($factionName)){
            Factions::setStrength($factionName, Factions::getMaxStrength($factionName));
            $this->getHandler()->cancel();
            return;
        }
        if(Factions::getFreezeTime($factionName) === 0){
            Factions::setStrength($factionName, Factions::getMaxStrength($factionName));
            Factions::removeFreezeTime($factionName);
            $this->getHandler()->cancel();
        }else{
            Factions::setFreezeTime($factionName, Factions::getFreezeTime($factionName) - 1);
        }
    }
}

?>