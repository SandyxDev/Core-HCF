<?php

namespace venity\commands;

use venity\Loader;
use venity\player\Player;

use pocketmine\world\Level;
use pocketmine\utils\TextFormat as TE;
use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;

class NearCommand extends VanillaCommand {

    /**
     * NearCommand Constructor.
     */
    public function __construct(){
        parent::__construct("near", "Can see the players that are close to you", "near");
    }
    
    /**
     * @param CommandSender $sender
     * @param String $label
     * @param Array $args
     * @return void
     */
    public function execute(CommandSender $sender, String $label, Array $args) : void {
        if(!$sender->hasPermission("near.command.use")){
            $sender->sendMessage(TE::RED."You have not permissions to use this command");
            return;
        }
        $sender->sendMessage(TE::GOLD."Nearby Players: "."\n");
        foreach($sender->getWorld()->getNearbyEntities($sender->getBoundingBox()->expandedCopy(200, 200, 200)) as $player){
        	if($player instanceof Player)
            $sender->sendMessage(TE::RESET.$player->getName().TE::GRAY."(".TE::DARK_RED.(int)$player->distance($sender)."m".TE::GRAY.")"."\n");
        }
    }
}

?>