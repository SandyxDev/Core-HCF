<?php

namespace venity\commands;

use venity\{Loader, Factions};
use venity\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;

class LocationCommand extends VanillaCommand {

    /**
     * LocationCommand Constructor.
     */
    public function __construct(){
        parent::__construct("tl", "Send your position to your faction members", "tl");
    }
    
    /**
     * @param CommandSender $sender
     * @param String $label
     * @param Array $args
     * @return void
     */
    public function execute(CommandSender $sender, String $label, Array $args) : void {
        if(!Factions::inFaction($sender->getName())){
            $sender->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("sender_not_in_faction")));
            return;
        }
        if($sender->getChat() === Player::FACTION_CHAT){
            $sender->setChat(Player::FACTION_CHAT);
            $sender->chat("World: ".$sender->getWorld()->getFolderName()." "."["."X: ".$sender->getFloorX()." "."Y: ".$sender->getFloorY()." "."Z: ".$sender->getFloorZ()."]");
        }
        if($sender->getChat() === Player::PUBLIC_CHAT){
            $sender->setChat(Player::FACTION_CHAT);
            $sender->chat("World: ".$sender->getWorld()->getFolderName()." "."["."X: ".$sender->getFloorX()." "."Y: ".$sender->getFloorY()." "."Z: ".$sender->getFloorZ()."]");
            $sender->setChat(Player::PUBLIC_CHAT);
        }
    }
}

?>