<?php

namespace venity\commands;

use venity\Loader;
use venity\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;


class PortalCrates extends VanillaCommand {
	
	/** @var Vaute */
	protected $plugin;
	
	/**
	 * PingCommand Constructor.
	 * @param 
	 */
	public function __construct(){
		parent::__construct("PortalCrates", "Claim Your Keys", "crates");
	}
	
	public function execute(CommandSender $sender, string $label, array $args){
		if(!$sender instanceof Player){
			$sender->sendMessage(TE::RED."Use this command in the game!");
			return;
		}
		$sender->sendMessage(TE::RED.'You Dont Have Keys!');
	}
}