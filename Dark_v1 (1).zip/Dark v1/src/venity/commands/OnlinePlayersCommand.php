<?php

namespace venity\commands;

use venity\Loader;
use venity\player\Player;

use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;
use pocketmine\utils\TextFormat as TE;

class OnlinePlayersCommand extends VanillaCommand {
	
	/**
	 * OnlinePlayers Constructor.
	 */
	public function __construct(){
		parent::__construct("players", "online players info", "players");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		$sender->sendMessage(TE::GRAY."----------------------------");
		$sender->sendMessage(TE::LIGHT_PURPLE."Connected Players: ".TE::GRAY.count(Loader::getInstance()->getServer()->getOnlinePlayers()));
		$sender->sendMessage(TE::GRAY."----------------------------");
	}
}

?>