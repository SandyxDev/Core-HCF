<?php

namespace venity\commands;

use venity\Loader;
use venity\player\{Player, PlayerBase};

  
use venity\utils\Time;

use pocketmine\item\{Item, ItemIds};
use pocketmine\item\ItemFactory;
use pocketmine\utils\TextFormat as TE;
use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;

class ReclaimCommand extends VanillaCommand {
	
	/**
	 * ReclaimCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("reclaim", "Claim your Map rewards", "reclaim");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
	 * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if($sender->getRank() === "Owner" || $sender->getRank() === "Co-Owner"){
        	if($sender->getTimeReclaimRemaining() < time()){
        		try {
	        		$sender->resetReclaimTime();
	
					if(!PlayerBase::getData($sender->getName())->get("lives_claimed")) $sender->setLives(60);
					PlayerBase::setData($sender->getName(), "lives_claimed", true);
					
					CrateManager::giveKey($sender, "Ability", 27);
					CrateManager::giveKey($sender, "Comon", 36);
                    CrateManager::giveKey($sender, "Murder", 18);
                    CrateManager::giveKey($sender, "Dragon", 14);
                    CrateManager::giveKey($sender, "Mitycal", 14);
                    
                    	Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeReclaimRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
        if($sender->getRank() === "PlatForm-Admin" || $sender->getRank() === "Sr-Admin" || $sender->getRank() === "Admin" || $sender->getRank() === "Coordinator"){
        	if($sender->getTimeReclaimRemaining() < time()){
        		try {
	        		$sender->resetReclaimTime();
	
					if(!PlayerBase::getData($sender->getName())->get("lives_claimed")) $sender->setLives(60);
					PlayerBase::setData($sender->getName(), "lives_claimed", true);
					
					CrateManager::giveKey($sender, "Ability", 27);
					CrateManager::giveKey($sender, "Common", 36);
                    CrateManager::giveKey($sender, "Partner", 15);
                    CrateManager::giveKey($sender, "Premium", 9);
                    CrateManager::giveKey($sender, "Divinity", 9);
                    
                    	Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeReclaimRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
        if($sender->getRank() === "Sr-Mod" || $sender->getRank() === "Mod" || $sender->getRank() === "Trial-Mod"){
        	if($sender->getTimeReclaimRemaining() < time()){
        		try {
	        		$sender->resetReclaimTime();
	
					if(!PlayerBase::getData($sender->getName())->get("lives_claimed")) $sender->setLives(60);
					PlayerBase::setData($sender->getName(), "lives_claimed", true);
					
					CrateManager::giveKey($sender, "Ability", 20);
					CrateManager::giveKey($sender, "Common", 36);
                    CrateManager::giveKey($sender, "Partner", 15);
                    CrateManager::giveKey($sender, "Premium", 5);
                    CrateManager::giveKey($sender, "Divinity", 6);
                    
                    	Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeReclaimRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
        if($sender->getRank() === "Trainee" || $sender->getRank() === "Support"){
        	if($sender->getTimeReclaimRemaining() < time()){
        		try {
	        		$sender->resetReclaimTime();
	
					if(!PlayerBase::getData($sender->getName())->get("lives_claimed")) $sender->setLives(60);
					PlayerBase::setData($sender->getName(), "lives_claimed", true);
					
					CrateManager::giveKey($sender, "Ability", 17);
					CrateManager::giveKey($sender, "Comon", 25);
                    CrateManager::giveKey($sender, "murder", 10);
                    CrateManager::giveKey($sender, "dragon", 2);
                    CrateManager::giveKey($sender, "Mistery", 3);
                    
                    	Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeReclaimRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
        if($sender->getRank() === "Partner" || $sender->getRank() === "TikTok"){
        	if($sender->getTimeReclaimRemaining() < time()){
        		try {
	        		$sender->resetReclaimTime();
	
					if(!PlayerBase::getData($sender->getName())->get("lives_claimed")) $sender->setLives(60);
					PlayerBase::setData($sender->getName(), "lives_claimed", true);
					
					CrateManager::giveKey($sender, "Ability", 27);
					CrateManager::giveKey($sender, "Comon", 36);
                    CrateManager::giveKey($sender, "Murder", 18);
                    CrateManager::giveKey($sender, "Mistery", 14);
                    CrateManager::giveKey($sender, "Mitycal", 14);
                    
                    	Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeReclaimRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
        if($sender->getRank() === "Guest"){
        	if($sender->getTimeReclaimRemaining() < time()){
        		try {
	        		$sender->resetReclaimTime();
	
					if(!PlayerBase::getData($sender->getName())->get("lives_claimed")) $sender->setLives(60);
					PlayerBase::setData($sender->getName(), "lives_claimed", true);
					
					CrateManager::giveKey($sender, "Ability", 27);
					CrateManager::giveKey($sender, "Comon", 36);
                    CrateManager::giveKey($sender, "Dragon", 18);
                    CrateManager::giveKey($sender, "Murder", 13);
                    CrateManager::giveKey($sender, "Rare", 14);
                    
                    	Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeReclaimRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
        if($sender->getRank() === "YouTuber"){
        	if($sender->getTimeReclaimRemaining() < time()){
        		try {
	        		$sender->resetReclaimTime();
	
					if(!PlayerBase::getData($sender->getName())->get("lives_claimed")) $sender->setLives(60);
					PlayerBase::setData($sender->getName(), "lives_claimed", true);
					
					CrateManager::giveKey($sender, "Ability", 27);
					CrateManager::giveKey($sender, "Common", 36);
                    CrateManager::giveKey($sender, "Partner", 18);
                    CrateManager::giveKey($sender, "Premium", 6);
                    CrateManager::giveKey($sender, "Divinity", 7);
                    
                    	Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeReclaimRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
        if($sender->getRank() === "Streamer"){
        	if($sender->getTimeReclaimRemaining() < time()){
        		try {
	        		$sender->resetReclaimTime();
	
					if(!PlayerBase::getData($sender->getName())->get("lives_claimed")) $sender->setLives(60);
					PlayerBase::setData($sender->getName(), "lives_claimed", true);
					
					CrateManager::giveKey($sender, "Ability", 27);
					CrateManager::giveKey($sender, "Common", 36);
                    CrateManager::giveKey($sender, "Partner", 18);
                    CrateManager::giveKey($sender, "Premium", 14);
                    CrateManager::giveKey($sender, "Divinity", 14);
                    
                    	Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeReclaimRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
        if($sender->getRank() === "MiniYT"){
        	if($sender->getTimeReclaimRemaining() < time()){
        		try {
	        		$sender->resetReclaimTime();
	
					if(!PlayerBase::getData($sender->getName())->get("lives_claimed")) $sender->setLives(60);
					PlayerBase::setData($sender->getName(), "lives_claimed", true);
					
					CrateManager::giveKey($sender, "Ability", 27);
					CrateManager::giveKey($sender, "Common", 36);
                    CrateManager::giveKey($sender, "Partner", 18);
                    CrateManager::giveKey($sender, "Premium", 4);
                    CrateManager::giveKey($sender, "Divinity", 5);
                    
                    	Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeReclaimRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
        if($sender->getRank() === "Premium"){
        	if($sender->getTimeReclaimRemaining() < time()){
        		try {
	        		$sender->resetReclaimTime();
	
					if(!PlayerBase::getData($sender->getName())->get("lives_claimed")) $sender->setLives(60);
					PlayerBase::setData($sender->getName(), "lives_claimed", true);
					
					CrateManager::giveKey($sender, "Ability", 27);
					CrateManager::giveKey($sender, "Common", 36);
                    CrateManager::giveKey($sender, "Partner", 18);
                    CrateManager::giveKey($sender, "Premium", 14);
                    CrateManager::giveKey($sender, "Divinity", 14);
                    
                    	Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeReclaimRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
        if($sender->getRank() === "Divinity"){
        	if($sender->getTimeReclaimRemaining() < time()){
        		try {
	        		$sender->resetReclaimTime();
	
					if(!PlayerBase::getData($sender->getName())->get("lives_claimed")) $sender->setLives(60);
					PlayerBase::setData($sender->getName(), "lives_claimed", true);
					
					CrateManager::giveKey($sender, "Ability", 27);
					CrateManager::giveKey($sender, "Common", 36);
                    CrateManager::giveKey($sender, "Partner", 18);
                    CrateManager::giveKey($sender, "Premium", 4);
                    CrateManager::giveKey($sender, "Divinity", 15);
                    
                    	Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeReclaimRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
        if($sender->getRank() === "Platium"){
        	if($sender->getTimeReclaimRemaining() < time()){
        		try {
	        		$sender->resetReclaimTime();
	
					if(!PlayerBase::getData($sender->getName())->get("lives_claimed")) $sender->setLives(60);
					PlayerBase::setData($sender->getName(), "lives_claimed", true);
					
					CrateManager::giveKey($sender, "Ability", 27);
					CrateManager::giveKey($sender, "Common", 36);
                    CrateManager::giveKey($sender, "Partner", 18);
                    CrateManager::giveKey($sender, "Divinity", 4);
                    
                    	Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeReclaimRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
        if($sender->getRank() === "Hero"){
        	if($sender->getTimeReclaimRemaining() < time()){
        		try {
	        		$sender->resetReclaimTime();
	
					if(!PlayerBase::getData($sender->getName())->get("lives_claimed")) $sender->setLives(60);
					PlayerBase::setData($sender->getName(), "lives_claimed", true);
					
					CrateManager::giveKey($sender, "Ability", 17);
					CrateManager::giveKey($sender, "Common", 36);
                    CrateManager::giveKey($sender, "Partner", 18);
                    
                    	Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeReclaimRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
        if($sender->getRank() === "Classic"){
        	if($sender->getTimeReclaimRemaining() < time()){
        		try {
	        		$sender->resetReclaimTime();
	
					if(!PlayerBase::getData($sender->getName())->get("lives_claimed")) $sender->setLives(60);
					PlayerBase::setData($sender->getName(), "lives_claimed", true);
					
					CrateManager::giveKey($sender, "Ability", 27);
					CrateManager::giveKey($sender, "Common", 25);
                    CrateManager::giveKey($sender, "Partner", 18);
                    
                    	Loader::getInstance()->getServer()->broadcastMessage(str_replace(["&", "{playerName}", "{rank}"], ["§", $sender->getName(), $sender->getRank()], Loader::getConfiguration("messages")->get("player_reclaim_correctly")));
				} catch(\Exception $exception){
					$sender->sendMessage($exception->getMessage());
				}
            }else{
            	$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeReclaimRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
			}
		}
}
}

?>
