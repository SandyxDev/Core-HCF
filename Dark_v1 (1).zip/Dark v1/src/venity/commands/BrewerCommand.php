<?php

namespace venity\commands;

use venity\{Loader, Factions};
use venity\player\Player;

use venity\utils\Time;

use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;
use pocketmine\utils\{Config, TextFormat as TE};

use pocketmine\math\Vector3;
use pocketmine\block\Block;
use pocketmine\tile\{Tile, Chest};
use pocketmine\world\Position;
use pocketmine\item\{Item, ItemIds};
use pocketmine\item\ItemFactory;

class BrewerCommand extends VanillaCommand {
	
	/**
	 * BrewerCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("brewer", "Can get six chests full of potions", "brewer");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if(Factions::getRegionName($sender) !== Factions::getFaction($sender->getName())){
			$sender->sendMessage(TE::RED."You can only execute this command in your claim!");
			return;
		}
		if($sender->getTimeBrewerRemaining() < time()){
			$position = $sender->getPosition();
			/** TODO: 4 variables are implemented to make the combination of chests */
			$tile1 = self::createTileChest($position);
		
			$tile2 = self::createTileChest(new Position($position->x + 1, $position->y, $position->z, $position->getWorld()));
		
			$tile3 = self::createTileChest(new Position($position->x, $position->y + 1, $position->z, $position->getWorld()));
		
			$tile4 = self::createTileChest(new Position($position->x + 1, $position->y + 1, $position->z, $position->getWorld()));

			$tile5 = self::createTileChest(new Position($position->x, $position->y + 2, $position->z, $position->getWorld()));

			$tile6 = self::createTileChest(new Position($position->x + 1, $position->y + 2, $position->z, $position->getWorld()));

		
			/** @var ItemIds */
			for($index = 0; $index <= 26; $index++){
				$tile1->getInventory()->setItem($index,  (new ItemFactory)->get(ItemIds::SPLASH_POTION, 22, 1));
				$tile2->getInventory()->setItem($index,  (new ItemFactory)->get(ItemIds::SPLASH_POTION, 22, 1));
				$tile3->getInventory()->setItem($index,  (new ItemFactory)->get(ItemIds::SPLASH_POTION, 22, 1));
				$tile4->getInventory()->setItem($index,  (new ItemFactory)->get(ItemIds::SPLASH_POTION, 16, 1));
				$tile5->getInventory()->setItem($index,  (new ItemFactory)->get(ItemIds::SPLASH_POTION, 13, 1));
				$tile6->getInventory()->setItem($index,  (new ItemFactory)->get(ItemIds::POTION, 8, 1));

			}
			$sender->resetBrewerTime();
		}else{
			$sender->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTime($sender->getTimeBrewerRemaining())], Loader::getConfiguration("messages")->get("function_cooldown")));
        }
	}
	
	/**
	 * @param Position $position
	 * @return Tile
	 */
	protected static function createTileChest(Position $position) : Tile {
		try {
			$chest = Tile::createTile("Chest", $position->getWorld(), Chest::createNBT($position));
			$position->getWorld()->setBlock(new Vector3($chest->getX(), $chest->getY(), $chest->getZ()), (new BlockFactory)->get(Block::CHEST));
			return $chest;
		} catch (\Exception $exception) {
			Loader::getInstance()->getLogger()->error($exception->getMessage());
		}
	}
}

?>