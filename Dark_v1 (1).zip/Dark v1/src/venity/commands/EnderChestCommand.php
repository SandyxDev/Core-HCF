<?php

namespace venity\commands;

use venity\Loader;
use venity\player\Player;

use venity\API\InvMenu\type\EnderChestInventory;

use pocketmine\utils\TextFormat as TE;
use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;

use pocketmine\network\mcpe\protocol\BlockActorDataPacket;
use pocketmine\network\mcpe\protocol\UpdateBlockPacket;

class EnderChestCommand extends VanillaCommand {
	
	/**
	 * EnderChestCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("enderchest", "Can open your EnderChest", "ce");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		$inventory = new EnderChestInventory();
		$inventory->openInventory($sender);
	}
}

?>