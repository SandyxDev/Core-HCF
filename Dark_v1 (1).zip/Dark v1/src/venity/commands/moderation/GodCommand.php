<?php

namespace venity\commands\moderation;

use venity\Loader;
use venity\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;

class GodCommand extends VanillaCommand {
	
	/**
	 * GodCommand Constructor.
	 */
	public function __construct(){
		parent::__construct("god", "place or destroy block", "god");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
		if(!$sender->hasPermission(DefaultPermissions::ROOT_OPERATOR)){
			$sender->sendMessage(TE::RED."You have not permissions to use this command");
			return;
		}
		if($sender->isGodMode()){
			$sender->setGodMode(false);
			$sender->sendMessage(TE::RED."You just desactivated god mode!");
		}else{
			$sender->setGodMode(true);
			$sender->sendMessage(TE::GREEN."You just activated god mode!");
        }
	}
}

?>