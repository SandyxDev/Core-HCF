<?php

namespace venity\commands\moderation;

use venity\Loader;
use venity\player\Player;

use venity\item\specials\{AntiTrapper,
    NinjaShear,
    SecondChance,
    StormBreaker,
    EggPorts,
    Strength,
    Resistance,
    Invisibility,
    PotionCounter,
    Firework,
    LoggerBait,
    RageBrick,
    Berserk,
    Energy,
    Medkit,
    RareBrick};

use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;
use pocketmine\utils\TextFormat as TE;

class SpecialItemsCommand extends VanillaCommand {
	
	/**
	 * SpecialItemsCommand Constructor.
	 */
	public function __construct(){
        parent::__construct("items", "dont working", "items");
        //Get all special items from the server
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
     * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
        if(!$sender->hasPermission(DefaultPermissions::ROOT_OPERATOR)){
			$sender->sendMessage(TE::RED."You have not permissions to use this command");
			return;
        }
        if ($sender instanceof Player) {
            $stormbreaker = new StormBreaker();
            $antitrapper = new AntiTrapper();
            $secondchance = new SecondChance();
            $eggports = new EggPorts();
            $strength = new Strength();
            $resistance = new Resistance();
            $invisibility = new Invisibility();
            $ragebrick = new RageBrick();
            $potionCounter = new PotionCounter();
            $berserk = new Berserk();
            $medkit = new Medkit();
            $energy = new Energy();

            $firework = new Firework();
            $loggerbait = new LoggerBait();
            $ninjashear = new NinjaShear();

            $sender->getInventory()->addItem($ninjashear);
            $sender->getInventory()->addItem($stormbreaker);
            $sender->getInventory()->addItem($antitrapper);
            $sender->getInventory()->addItem($loggerbait);
            $sender->getInventory()->addItem($eggports);
            $sender->getInventory()->addItem($strength);
            $sender->getInventory()->addItem($resistance);
            $sender->getInventory()->addItem($invisibility);
            $sender->getInventory()->addItem($ragebrick);
            $sender->getInventory()->addItem($potionCounter);
            $sender->getInventory()->addItem($firework);
            $sender->getInventory()->addItem($secondchance);
            $sender->getInventory()->addItem($berserk);
            $sender->getInventory()->addItem($medkit);
            $sender->getInventory()->addItem($energy); 
        }
	}
}

?>