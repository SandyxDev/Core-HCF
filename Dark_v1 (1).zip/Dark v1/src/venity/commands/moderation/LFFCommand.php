<?php

namespace venity\commands\moderation;

use venity\{Loader, Factions};
use venity\player\Player;

use pocketmine\command\CommandSender;
use pocketmine\command\defaults\VanillaCommand;
use pocketmine\permission\DefaultPermissions;
use pocketmine\utils\TextFormat as TE;

class LFFCommand extends VanillaCommand {
	
	public function __construct(){
		parent::__construct("lff", "lff?", "lff");
	}
	
	/**
	 * @param CommandSender $sender
	 * @param String $label
	 * @param Array $args
	 * @return void
	 */
	public function execute(CommandSender $sender, String $label, Array $args) : void {
        
        if(Factions::inFaction($sender->getName())){
    $sender->sendMessage(TE::RED . "You cannot run this command if you are already in a faction");
    return;
    }
    Loader::getInstance()->getServer()->broadcastMessage("§8---------------------------------------------");
        Loader::getInstance()->getServer()->broadcastMessage("§l§c".$sender->getName()." §l§eEsta Buscando Faction!");
        Loader::getInstance()->getServer()->broadcastMessage("§8---------------------------------------------");
  }	
}

?>
