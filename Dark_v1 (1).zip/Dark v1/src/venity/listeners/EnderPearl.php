<?php

namespace venity\listeners;

use venity\Loader;
use venity\player\Player;

use venity\utils\{NBT, Time};

use venity\Task\EnderPearlTask;

use venity\Task\specials\EggTask;
use venity\enchantments\CustomEnchantment;

use pocketmine\utils\TextFormat as TE;
use pocketmine\math\Vector3;
use pocketmine\event\Listener;
use pocketmine\entity\Entity;
use pocketmine\nbt\tag\{CompoundTag, ShortTag};

use pocketmine\item\{Item, ItemIds};
use pocketmine\item\ItemFactory;
use pocketmine\world\{Position, Level};
use pocketmine\block\{Fence, FenceGate};

use pocketmine\event\player\PlayerInteractEvent;

class EnderPearl implements Listener {

    /**
     * EnderPearl Constructor.
     */
    public function __construct(){

    }

    /**
     * @param PlayerInteractEvent $event
     * @return void
     */
    public function onPlayerInteractEvent(PlayerInteractEvent $event) : void {
        $player = $event->getPlayer();
        $item = $event->getItem();
        $block = $event->getBlock();
        if($item instanceof \venity\item\FishingRod){
        	if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR){
        		$nbt = NBT::createWith($player);
                $entity = Entity::createEntity("FishingHook", $player->getPosition()->getWorld(), $nbt, $player);
                if($entity instanceof \venity\entities\FishingHook){
                	$entity->setMotion($entity->getMotion()->multiply($item->getThrowForce()));
                    $entity->spawnToAll();
                }
        	}
        }
        if($item instanceof \venity\item\SplashPotion){
        	if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR||$event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
        		$nbt = NBT::createWith($player);
                $nbt["PotionId"] = new ShortTag("PotionId", $item->getDamage());
                $entity = Entity::createEntity("SplashPotion", $player->getPosition()->getWorld(), $nbt, $player);
                if($entity instanceof \venity\entities\SplashPotion){
                	$entity->setMotion($entity->getMotion()->multiply($item->getThrowForce()));
                	if($player->isSurvival()){
                		$item->setCount($item->getCount() - 1);
                        $player->getInventory()->setItemInHand( (new ItemFactory)->get(ItemIds::AIR));
                    }
                    $entity->spawnToAll();
                }
        	}
        }
        if($item instanceof \venity\item\EnderPearl && $event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR){
            if($player->isEnderPearl()){
                $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getEnderPearlTime())], Loader::getConfiguration("messages")->get("enderpearl_cooldown")));
                $event->cancel();
                return;
            }
            $nbt = NBT::createWith($player);
            $entity = Entity::createEntity("EnderPearl", $player->getPosition()->getWorld(), $nbt, $player);
            if($entity instanceof \venity\entities\EnderPearl){
                $entity->setMotion($entity->getMotion()->multiply($item->getThrowForce()));
                if($player->isSurvival()){
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                }
                $entity->spawnToAll();
                $player->setEnderPearl(true);
                Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new EnderPearlTask($player), 20);
            }
        }
        if($item instanceof \venity\item\EnderPearl && $event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
            if($block instanceof Fence||$block instanceof FenceGate){
                $event->cancel();
                if($player->isEnderPearl()){
                    $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getEnderPearlTime())], Loader::getConfiguration("messages")->get("enderpearl_cooldown")));
                    $event->cancel();
                    return;
                }
                $nbt = NBT::createWith($player);
                $entity = Entity::createEntity("EnderPearl", $player->getPosition()->getWorld(), $nbt, $player);
                if($entity instanceof \venity\entities\EnderPearl){
                    $entity->setMotion($entity->getMotion()->multiply($item->getThrowForce()));
                    if($player->isSurvival()){
                        $item->setCount($item->getCount() - 1);
                        $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                    }
                    $entity->spawnToAll();
                    $player->setEnderPearl(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new EnderPearlTask($player), 20);
                }
            }
        }
        if($item instanceof \venity\item\specials\EggPorts && $item->setNamedTag(\venity\item\specials\EggPorts::CUSTOM_ITEM) instanceof CompoundTag && $event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR){
            if($player->isEgg()){
                $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getEggTime())], Loader::getConfiguration("messages")->get("eggport_cooldown")));
                $event->cancel();
                return;
            }
            $nbt = NBT::createWith($player);
            $entity = Entity::createEntity("Egg", $player->getPosition()->getWorld(), $nbt, $player);
            if($entity instanceof \venity\entities\Egg){
                $entity->setMotion($entity->getMotion()->multiply($item->getThrowForce()));
                if($player->isSurvival()){
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                }
                $entity->spawnToAll();
                $player->setEgg(true);
                Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new EggTask($player), 20);
            }
        }
        if($item instanceof \venity\item\specials\EggPorts && $item->setNamedTag(\venity\item\specials\EggPorts::CUSTOM_ITEM) instanceof CompoundTag && $event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
            if($block instanceof Fence||$block instanceof FenceGate){
                $event->cancel();
                if($player->isEgg()){
                    $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getEggTime())], Loader::getConfiguration("messages")->get("eggport_cooldown")));
                    $event->cancel();
                    return;
                }
                $nbt = NBT::createWith($player);
                $entity = Entity::createEntity("Egg", $player->getPosition()->getWorld(), $nbt, $player);
                if($entity instanceof \venity\entities\Egg){
                    $entity->setMotion($entity->getMotion()->multiply($item->getThrowForce()));
                    if($player->isSurvival()){
                        $item->setCount($item->getCount() - 1);
                        $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                    }
                    $entity->spawnToAll();
                    $player->setEgg(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new EggTask($player), 20);
                }
            }
        }
    }
}

?>