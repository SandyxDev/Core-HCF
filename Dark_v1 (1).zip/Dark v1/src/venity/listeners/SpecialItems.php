<?php

namespace venity\listeners;

use venity\{Loader, Factions};
use pocketmine\scheduler\ClosureTask;
use venity\player\Player;

use venity\utils\Time;
use venity\packages\PackageManager;

use venity\Task\{EnderPearlTask};

use venity\Task\specials\{AntiTrapperTask, SpecialItemTask, LoggerBaitTask, StormBreakerTask, PotionCounterTask, RagebrickTask, BerserkTask, MedkitTask, EnergyTask, StrengthTask, ResistanceTask, FireworkTask, SecondChanceTask};
use venity\Task\delayedtask\{StormBreakerDelayed, NinjaShearDelayed};

use venity\item\specials\{Custom, CustomProjectileItem, StormBreaker, AntiTrapper, NinjaShear, Strength, Resistance, Invisibility, PotionCounter, Firework, PrePearl, PartnerPackages, SecondChance, LoggerBait, Ragebrick, Berserk, Medkit, Energy, Cactus};
use pocketmine\utils\TextFormat as TE;
use pocketmine\event\Listener;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;

use pocketmine\item\{Item, ItemIds};
use pocketmine\item\ItemFactory;
use pocketmine\entity\{Effect, EffectInstance, Entity, Villager};
use pocketmine\block\{Fence, FenceGate, Fire};

use pocketmine\event\block\{BlockBreakEvent, BlockPlaceEvent};
use pocketmine\event\entity\{EntityDamageEvent, EntityDamageByEntityEvent, ProjectileHitEvent, ProjectileHitEntityEvent};
use pocketmine\event\player\PlayerInteractEvent;

class SpecialItems implements Listener
{

    /**
     * SpecialItems Constructor.
     */
    public function __construct()
    {

    }

    /**
     * @param EntityDamageEvent $event
     * @return void
     */
    public function onEntityDamageEvent(EntityDamageEvent $event): void
    {
        $player = $event->getEntity();
        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($player instanceof Player && $damager instanceof Player) {
                if ($event->getCause() === EntityDamageEvent::CAUSE_ENTITY_ATTACK) {
                    $item = $damager->getInventory()->getItemInHand();
                    if (!Factions::isSpawnRegion($damager) && $item instanceof StormBreaker && $item->setNamedTag(StormBreaker::CUSTOM_ITEM) instanceof CompoundTag) {

                        if (Factions::inFaction($player->getName()) && Factions::inFaction($damager->getName()) && Factions::getFaction($player->getName()) === Factions::getFaction($damager->getName())) return;

                        if ($damager->isStormBreaker()) {
                            $damager->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($damager->getStormBreakerTime())], Loader::getConfiguration("messages")->get("stormbreaker_cooldown")));
                            $event->cancel();
                            return;
                        }
                        $damager->sendMessage(str_replace(["&", "{playerName}"], ["§", $player->getName()], Loader::getConfiguration("messages")->get("stormbreaker_was_used_correctly")));

                        # This task is executed after a few seconds, to remove the player's helmet
                        Loader::getInstance()->getScheduler()->scheduleDelayedTask(new StormBreakerDelayed($player), 40);

                        $item->reduceUses($damager);
                        $damager->setStormBreaker(true);
                        Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new StormBreakerTask($damager), 20);
                    }

                    if (!Factions::isSpawnRegion($damager) && $item instanceof AntiTrapper && $item->setNamedTag(AntiTrapper::CUSTOM_ITEM) instanceof CompoundTag) {

                        if (Factions::inFaction($player->getName()) && Factions::inFaction($damager->getName()) && Factions::getFaction($player->getName()) === Factions::getFaction($damager->getName())) return;

                        if ($damager->isAntiTrapper()) {
                            $damager->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($damager->getAntiTrapperTime())], Loader::getConfiguration("messages")->get("antitrapper_cooldown")));
                            $event->cancel();
                            return;
                        }
                        $item->reduceUses($damager);
	                    $damager->setAntiTrapper(true);
                        //here we place the time for which the player cannot place blocks
                        $player->setAntiTrapperTarget(true);
                        Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new AntiTrapperTask($damager, $player), 20);
                    }
                    if (!Factions::isSpawnRegion($damager) && $item instanceof PotionCounter && $item->setNamedTag(PotionCounter::CUSTOM_ITEM) instanceof CompoundTag) {

                        if (Factions::inFaction($player->getName()) && Factions::inFaction($damager->getName()) && Factions::getFaction($player->getName()) === Factions::getFaction($damager->getName())) return;

                        if ($damager->isPotionCounter()) {
                            $damager->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($damager->getPotionCounterTime())], Loader::getConfiguration("messages")->get("potioncounter_cooldown")));
                            $event->cancel();
                            return;
                        }
                        $item->reduceUses($damager);

                        $inventory = [];
                        $enderchest = [];
                        foreach ($player->getInventory()->getContents() as $slot => $item) {
                            if ($item->getId() === 438 && $item->getDamage() === 22) {
                                $inventory[] = $item;
                            }
                        }
                        foreach ($player->getEnderChestInventory()->getContents() as $slot => $item) {
                            if ($item->getId() === 438 && $item->getDamage() === 22) {
                                $enderchest[] = $item;
                            }
                        }
                        $damager->sendMessage(str_replace(["&", "{playerName}", "{potionsTotal}"], ["§", $player->getName(), count($inventory)], Loader::getConfiguration("messages")->get("potioncounter_count_target_inventory_potion")));
                        $damager->sendMessage(str_replace(["&", "{playerName}", "{potionsTotal}"], ["§", $player->getName(), count($enderchest)], Loader::getConfiguration("messages")->get("potioncounter_count_target_enderchest_potion")));

                        $damager->setPotionCounter(true);
                        Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new PotionCounterTask($damager), 20);
                    }
                }
            }
        }
    }

    /**
     * @param BlockBreakEvent $event
     * @return void
     */
    public function onBlockBreak(BlockBreakEvent $event): void
    {
        $player = $event->getPlayer();
        if ($player->isAntiTrapperTarget()) {
            $player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getAntiTrapperTime())], Loader::getConfiguration("messages")->get("antitrapper_target_cooldown")));
            $event->cancel();
        }
    }

    /**
     * @param BlockPlaceEvent $event
     * @return void
     */
    public function onBlockPlace(BlockPlaceEvent $event): void
    {
        $player = $event->getPlayer();
        if ($player->isAntiTrapperTarget()) {
            $player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getAntiTrapperTime())], Loader::getConfiguration("messages")->get("antitrapper_target_cooldown")));
            $event->cancel();
        }
    }

    /**
     * @param PlayerInteractEvent $event
     * @return void
     */
    public function onPlayerInteractEvent(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $item = $event->getItem();
        if ($player instanceof Player) {
            if ($player->isAntiTrapperTarget()) {
                if ($block instanceof Fence || $block instanceof FenceGate) {
                    $player->sendMessage(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getAntiTrapperTime())], Loader::getConfiguration("messages")->get("antitrapper_target_cooldown")));
                    $event->cancel();
                }
            }
            if ($item instanceof Strength && $item->setNamedTag(Strength::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isStrength()) {
                        $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getStrengthTime())], Loader::getConfiguration("messages")->get("strength_cooldown")));
                        $event->cancel();
                        return;
                    }
                    $player->addEffect(new EffectInstance(Player::getEffectName('strength'), 15 * 10, 1));

                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayerExact($value);
                            if ($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 30) {
                                $online->addEffect(new EffectInstance(Player::getEffectName('strength'), 15 * 10, 1));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                    $player->setStrength(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new StrengthTask($player), 20);
                }
            }
            if ($item instanceof LoggerBait && $item->setNamedTag(LoggerBait::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isLoggerBait()) {
                        $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getLoggerBaitTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                        $event->cancel();
                        return;
                    }
                    $nbt = Entity::createBaseNBT(new Vector3((float)$player->getPosition()->getX(), (float)$player->getPosition()->getY(), (float)$player->getPosition()->getZ()));
                    $human = new Villager($player->getPosition()->getWorld(), $nbt);
                    $human->setNameTagVisible(true);
                    $human->setNameTagAlwaysVisible(true);
                    $human->yaw = $player->getYaw();
                    $human->pitch = $player->getPitch();
                    $human->setNameTag(TE::GRAY . "(Combat-Logger) " . TE::RED . $player->getName() . TE::GRAY);
                    $human->spawnToAll();
                    $player->setLoggerBait(true);
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                    $player->setLoggerBait(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new LoggerBaitTask($player), 20);
                }
            }      
            if ($item instanceof RageBrick && $item->setNamedTag(RageBrick::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isRagebrick()) {
                        $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getRagebrickTime())], Loader::getConfiguration("messages")->get("ragebrick_cooldown")));
                        $event->cancel();
                        return;
                    }
                    $player->addEffect(new EffectInstance(Player::getEffectName('strength'), 20 * 10, 1));


                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayerExact($value);
                            if ($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 30) {
                                $online->addEffect(new EffectInstance(Player::getEffectName('strength'), 20 * 10, 1));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                    $player->setRagebrick(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new RagebrickTask($player), 20);
                }
            }
             if ($item instanceof Berserk && $item->setNamedTag(Berserk::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isBerserk()) {
                        $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getBerserkTime())], Loader::getConfiguration("messages")->get("berserk_cooldown")));
                        $event->cancel();
                        return;
                    }
                    $player->addEffect(new EffectInstance(Player::getEffectName('strength'), 15 * 10, 2));
                    $player->addEffect(new EffectInstance(Player::getEffectName('resistance'), 15 * 10, 2));

                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayerExact($value);
                            if ($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 30) {
                                $online->addEffect(new EffectInstance(Player::getEffectName('strength'), 15 * 10, 1));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                    $player->setBerserk(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new BerserkTask($player), 20);
                }
            }
             if ($item instanceof Medkit && $item->setNamedTag(Medkit::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isMedkit()) {
                        $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getMedkitTime())], Loader::getConfiguration("messages")->get("medkit_cooldown")));
                        $event->cancel();
                        return;
                    }
                    $player->addEffect(new EffectInstance(Player::getEffectName('regeneration'), 15 * 10, 1));
                    $player->addEffect(new EffectInstance(Player::getEffectName('resistance'), 15 * 10, 2));
                    $player->addEffect(new EffectInstance(Effect::getEffect(Effect::ABSORPTION), 15 * 10, 3));    

                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayerExact($value);
                            if ($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 30) {
                                $online->addEffect(new EffectInstance(Player::getEffectName('resistance'), 15 * 10, 1));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                    $player->setMedkit(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new MedkitTask($player), 20);
                }
            }
             if ($item instanceof Energy && $item->setNamedTag(Energy::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isEnergy()) {
                        $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getEnergyTime())], Loader::getConfiguration("messages")->get("energy_cooldown")));
                        $event->cancel();
                        return;
                    }
                    $player->addEffect(new EffectInstance(Player::getEffectName('strength'), 15 * 10, 1));
                    $player->addEffect(new EffectInstance(Player::getEffectName('speed'), 20 * 10, 2));

                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayerExact($value);
                            if ($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 30) {
                                $online->addEffect(new EffectInstance(Player::getEffectName('strength'), 15 * 10, 1));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                    $player->setEnergy(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new EnergyTask($player), 20);
                }
            }
             if ($item instanceof Resistance && $item->setNamedTag(Resistance::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isResistance()) {
                        $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getResistanceTime())], Loader::getConfiguration("messages")->get("resistance_cooldown")));
                        $event->cancel();
                        return;
                    }
                    $player->addEffect(new EffectInstance(Player::getEffectName('resistance'), 15 * 10, 2));

                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayerExact($value);
                            if ($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 30) {
                                $online->addEffect(new EffectInstance(Player::getEffectName('resistance'), 15 * 10, 2));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                    $player->setResistance(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new ResistanceTask($player), 20);
                }
            }

            if ($item instanceof Invisibility && $item->setNamedTag(Invisibility::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isSpecialItem()) {
                        $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getSpecialItemTime())], Loader::getConfiguration("messages")->get("specialitem_cooldown")));
                        $event->cancel();
                        return;
                    }
                    $player->addEffect(new EffectInstance(Player::getEffectName('invisibility'), 20 * 60, 1));

                    # This code checks if the player using the item has a faction to give it the effects in the specified radius.
                    if (Factions::inFaction($player->getName())) {
                        foreach (Factions::getPlayers(Factions::getFaction($player->getName())) as $value) {
                            $online = Loader::getInstance()->getServer()->getPlayerExact($value);
                            if ($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 30) {
                                $online->addEffect(new EffectInstance(Player::getEffectName('resistance'), 20 * 60, 1));
                            }
                        }
                    }
                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                    $player->setSpecialItem(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SpecialItemTask($player), 20);
                }
            }
            if ($item instanceof Firework && $item->setNamedTag(Firework::CUSTOM_ITEM) instanceof CompoundTag) {
                if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR) {
                    if ($player->isFirework()) {
                        $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getFireworkTime())], Loader::getConfiguration("messages")->get("firework_cooldown")));
                        $event->cancel();
                        return;
                    }
                    $player->knockBack($player, 0, $player->getDirectionVector()->x, $player->getDirectionVector()->z, 2.1);

                    $item->setCount($item->getCount() - 1);
                    $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                    $player->setFirework(true);
                    Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new FireworkTask($player), 20);
                }
            }
        }
        if($item instanceof SecondChance && $item->setNamedTag(SecondChance::CUSTOM_ITEM) instanceof CompoundTag){
            if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR){
                if($player->isSecondChance()){
                    $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getSecondChanceTime())], Loader::getConfiguration("messages")->get("secondchance_cooldown")));
                    $event->cancel();
                    return;
                }
                if($player->isEnderPearl()){
                    $player->setEnderPearl(false);
                }else{
                    $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("secondchance_cannot_use_if_not_have_cooldown")));
                    $event->cancel();
                    return;
                }
                $item->setCount($item->getCount() - 1);
                $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                $player->setSecondChance(true);
                Loader::getInstance()->getScheduler()->scheduleRepeatingTask(new SecondChanceTask($player), 20);
            }
        }
        if($item instanceof NinjaShear && $item->setNamedTag(NinjaShear::CUSTOM_ITEM) instanceof CompoundTag){
            if($player->isNinjaShear()){
                $player->sendTip(str_replace(["&", "{time}"], ["§", Time::getTimeToString($player->getNinjaShearTime())], Loader::getConfiguration("messages")->get("ninjashear_cooldown")));
                $event->cancel();
                return;
            }
            if(empty($player->getNinjaShearPosition())){
                $player->sendTip(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("ninjashear_have_no_hit_registered")));
                return;
            }
            $player->sendMessage(str_replace(["&"], ["§"], Loader::getConfiguration("messages")->get("ninjashear_was_used_correctly")));
            
            # This task runs after a few seconds, to teleport the player to the saved position
            Loader::getInstance()->getScheduler()->scheduleDelayedTask(new NinjaShearDelayed($player, $player->getNinjaShearPosition()), 20);
            
            $item->reduceUses($player);
            $player->setNinjaShear(true);
            $player->setNinjaShearTime(Loader::getDefaultConfig("Cooldowns")["NinjaShear"]);
        }
        if($item instanceof PartnerPackages && $item->setNamedTag(PartnerPackages::CUSTOM_ITEM) instanceof CompoundTag){
            if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR){
                $package = PackageManager::getPackage();
                if(empty($package)) return;

                foreach(PackageManager::getRewards() as $item){
                    if(!$player->getInventory()->canAddItem(ItemFactory::get($item->getId(), $item->getDamage()))){
                        return;
                    }
                    $player->getInventory()->addItem($item);
                    $player->getInventory()->setItemInHand($player->getInventory()->getItemInHand()->setCount($player->getInventory()->getItemInHand()->getCount() - 1));
                    $player->sendMessage(str_replace(["&", "{itemName}"], ["§", $item->getName()], Loader::getConfiguration("messages")->get("package_give_reward_correctly")));

                    $source = (new Vector3($player->getPosition()->x, $player->getPosition()->y, $player->getPosition()->z))->floor();
                    $player->getPosition()->getWorld()->addParticle(new HugeExplodeSeedParticle($source));
                    $player->getPosition()->getWorld()->addSound(new BlazeShootSound($source));
                }
            }
        }
        if($item instanceof PartnerPackages && $item->setNamedTag(PartnerPackages::CUSTOM_ITEM) instanceof CompoundTag){
            if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_AIR){
                $package = PackageManager::getPackage();
                if(empty($package)) return;

                foreach(PackageManager::getRewards() as $item){
                    if(!$player->getInventory()->canAddItem(ItemFactory::get($item->getId(), $item->getDamage()))){
                        return;
                    }
                    $player->getInventory()->addItem($item);
                    $player->getInventory()->setItemInHand($player->getInventory()->getItemInHand()->setCount($player->getInventory()->getItemInHand()->getCount() - 1));
                    $player->sendMessage(str_replace(["&", "{itemName}"], ["§", $item->getName()], Loader::getConfiguration("messages")->get("package_give_reward_correctly")));

                    $source = (new Vector3($player->getPosition()->x, $player->getPosition()->y, $player->getPosition()->z))->floor();
                    $player->getPosition()->getWorld()->addParticle(new HugeExplodeSeedParticle($source));
                    $player->getPosition()->getWorld()->addSound(new BlazeShootSound($source));
                    
                    }
        if($projectile instanceof Snowball){
			$sender = $projectile->getOwningEntity();
			if($sender instanceof Player and $event instanceof ProjectileHitEntityEvent and $sender->hasPermission("Snowball.use")){
				$player = $event->getEntityHit();
				if($player instanceof Player){
					if(!Factions::isSpawnRegion($sender) && !Factions::isSpawnRegion($player) && Factions::getFaction($sender->getName()) !== Factions::getFaction($player->getName())){
						if($player->getName() === $sender->getName()){
							return;
						}
						$sender->sendMessage(TE::BOLD.TE::GOLD."".TE::RESET.TE::GRAY."".TE::GRAY."you correctly marked Disbed ".TE::BOLD.TE::GREEN.$player->getName());
						$player->addEffect(new EffectInstance(Effect::getEffect(Effect::SLOWNESS), 20 * 5, 0));
						$player->addEffect(new EffectInstance(Effect::getEffect(Effect::NAUSEA), 20 * 5, 0));
                  } 
                }
            }
        }
    }
}
    }
}
