<?php

namespace venity\listeners\interact;

use venity\{Loader, Factions};
use venity\player\Player;

use venity\utils\Translator;

use pocketmine\entity\effect\{Effect, EffectInstance};
use pocketmine\event\Listener;
use pocketmine\item\{Item, ItemIds};
use pocketmine\item\ItemFactory;

use pocketmine\event\player\{PlayerInteractEvent};
use pocketmine\event\entity\{EntityDamageEvent, EntityDamageByEntityEvent};

class Ghost implements Listener {
	
	/** @var Loader */
	protected $plugin;
	
	/**
	 * Ghost Constructor.
	 */
	public function __construct(){
		
	}
	
	/**
     * @param PlayerInteractEvent $event
     * @return void
     */
	public function onPlayerInteractEvent(PlayerInteractEvent $event) : void {
		$player = $event->getPlayer();
		$item = $event->getItem();
		if($player->isGhostClass()){
			if($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK){
				switch($item->getId()){
					case ItemIds::SUGAR:
						if(Factions::isSpawnRegion($player)){
							$event->cancel();
							return;
						}
						if($player->getGhostEnergy() < $player->getGhostEnergyCost($item->getId())){
							$player->sendMessage(str_replace(["&", "{currentEnergy}", "{needEnergy}"], ["§", $player->getGhostEnergy(), $player->getGhostEnergyCost($item->getId())], Loader::getConfiguration("messages")->get("ghost_not_enough_energy")));
							return;
						}
						$effect = new EffectInstance(Player::getEffectName('speed'), 20 * 10, 2);

						$player->setGhostEnergy($player->getGhostEnergy() - $player->getGhostEnergyCost($item->getId()));
						$player->addEffect($effect);
                        $player->sendMessage(str_replace(["&", "{effectName}", "{effectLevel}"], ["§", Translator::effectToStringByObject($effect), $effect->getAmplifier()], Loader::getConfiguration("messages")->get("ghost_give_effects")));


                        $item->setCount($item->getCount() - 1);
                        $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                        if(Factions::inFaction($player->getName())){
                        	foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
                           	 $online = Loader::getInstance()->getServer()->getPlayerExact($value);
                        	    if($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 250){
                           	     	$online->addEffect($effect);
                           	    	$online->sendMessage(str_replace(["&", "{playerName}", "{effectName}", "{effectLevel}"], ["§", $player->getName(), Translator::effectToStringByObject($effect), $effect->getAmplifier()], Loader::getConfiguration("messages")->get("ghost_global_give_effects")));
                            	}
                            }
                        }
					break;
					case ItemIds::IRON_INGOT:
						if(Factions::isSpawnRegion($player)){
							$event->cancel();
							return;
						}
						if($player->getGhostEnergy() < $player->getGhostEnergyCost($item->getId())){
							$player->sendMessage(str_replace(["&", "{currentEnergy}", "{needEnergy}"], ["§", $player->getBardEnergy(), $player->getGhostEnergyCost($item->getId())], Loader::getConfiguration("messages")->get("ghost_not_enough_energy")));
							return;
						}
						$effect = new EffectInstance(Player::getEffectName('resistance'), 20 * 10, 3);

						$player->setGhostEnergy($player->getGhostEnergy() - $player->getGhostEnergyCost($item->getId()));
						$player->addEffect($effect);
						$player->sendMessage(str_replace(["&", "{effectName}", "{effectLevel}"], ["§", Translator::effectToStringByObject($effect), $effect->getAmplifier()], Loader::getConfiguration("messages")->get("bard_give_effects")));

						$item->setCount($item->getCount() - 1);
                        $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                        if(Factions::inFaction($player->getName())){
                        	foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
                           	 $online = Loader::getInstance()->getServer()->getPlayerExact($value);
                        	    if($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 250){
                           	     	$online->addEffect($effect);
									$online->sendMessage(str_replace(["&", "{playerName}", "{effectName}", "{effectLevel}"], ["§", $player->getName(), Translator::effectToStringByObject($effect), $effect->getAmplifier()], Loader::getConfiguration("messages")->get("ghost_global_give_effects")));
                            	}
                            }
                        }
					break;
					case ItemIds::BLAZE_POWDER:
						if(Factions::isSpawnRegion($player)){
							$event->cancel();
							return;
						}
						if($player->getGhostEnergy() < $player->getGhostEnergyCost($item->getId())){
							$player->sendMessage(str_replace(["&", "{currentEnergy}", "{needEnergy}"], ["§", $player->getGhostEnergy(), $player->getGhostEnergyCost($item->getId())], Loader::getConfiguration("messages")->get("ghost_not_enough_energy")));
							return;
						}
						$effect = new EffectInstance(Player::getEffectName('strength'), 15 * 10, 1);

						$player->setGhostEnergy($player->getGhostEnergy() - $player->getGhostEnergyCost($item->getId()));
						$player->addEffect($effect);
                        $player->sendMessage(str_replace(["&", "{effectName}", "{effectLevel}"], ["§", Translator::effectToStringByObject($effect), $effect->getAmplifier()], Loader::getConfiguration("messages")->get("ghost_give_effects")));

                        $item->setCount($item->getCount() - 1);
                        $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                        if(Factions::inFaction($player->getName())){
                        	foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
                           	 $online = Loader::getInstance()->getServer()->getPlayerExact($value);
                        	    if($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 250){
                           	     	$online->addEffect($effect);
									$online->sendMessage(str_replace(["&", "{playerName}", "{effectName}", "{effectLevel}"], ["§", $player->getName(), Translator::effectToStringByObject($effect), $effect->getAmplifier()], Loader::getConfiguration("messages")->get("ghost_global_give_effects")));
                            	}
                            }
                        }
					break;
					case ItemIds::GHAST_TEAR:
						if(Factions::isSpawnRegion($player)){
							$event->cancel();
							return;
						}
						if($player->getGhostEnergy() < $player->getGhostEnergyCost($item->getId())){
							$player->sendMessage(str_replace(["&", "{currentEnergy}", "{needEnergy}"], ["§", $player->getGhostEnergy(), $player->getGhostEnergyCost($item->getId())], Loader::getConfiguration("messages")->get("ghost_not_enough_energy")));
							return;
						}
						$effect = new EffectInstance(Player::getEffectName('regeneration'), 15 * 10, 2);

						$player->setGhostEnergy($player->getGhostEnergy() - $player->getGhostEnergyCost($item->getId()));
						$player->addEffect($effect);
                        $player->sendMessage(str_replace(["&", "{effectName}", "{effectLevel}"], ["§", Translator::effectToStringByObject($effect), $effect->getAmplifier()], Loader::getConfiguration("messages")->get("ghost_give_effects")));

                        $item->setCount($item->getCount() - 1);
                        $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                        if(Factions::inFaction($player->getName())){
                        	foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
                           	 $online = Loader::getInstance()->getServer()->getPlayerExact($value);
                        	    if($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 250){
                           	     	$online->addEffect($effect);
									$online->sendMessage(str_replace(["&", "{playerName}", "{effectName}", "{effectLevel}"], ["§", $player->getName(), Translator::effectToStringByObject($effect), $effect->getAmplifier()], Loader::getConfiguration("messages")->get("ghost_global_give_effects")));
                            	}
                            }
                        }
					break;
					case ItemIds::FEATHER:
						if(Factions::isSpawnRegion($player)){
							$event->cancel();
							return;
						}
						if($player->getGhostEnergy() < $player->getGhostEnergyCost($item->getId())){
							$player->sendMessage(str_replace(["&", "{currentEnergy}", "{needEnergy}"], ["§", $player->getGhostEnergy(), $player->getGhostEnergyCost($item->getId())], Loader::getConfiguration("messages")->get("ghost_not_enough_energy")));
							return;
						}
						$effect = new EffectInstance(Player::getEffectName('jump_boost'), 20 * 10, 5);

						$player->setBardEnergy($player->getBardEnergy() - $player->getGhostEnergyCost($item->getId()));
						$player->addEffect($effect);
                        $player->sendMessage(str_replace(["&", "{effectName}", "{effectLevel}"], ["§", Translator::effectToStringByObject($effect), $effect->getAmplifier()], Loader::getConfiguration("messages")->get("ghost_give_effects")));

                        $item->setCount($item->getCount() - 1);
                        $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                        if(Factions::inFaction($player->getName())){
                        	foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
                           	 $online = Loader::getInstance()->getServer()->getPlayerExact($value);
                        	    if($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 250){
                           	     	$online->addEffect($effect);
									$online->sendMessage(str_replace(["&", "{playerName}", "{effectName}", "{effectLevel}"], ["§", $player->getName(), Translator::effectToStringByObject($effect), $effect->getAmplifier()], Loader::getConfiguration("messages")->get("ghost_global_give_effects")));
                            	}
                            }
                        }
					break;
					case ItemIds::DYE:
						if(Factions::isSpawnRegion($player)){
							$event->cancel();
							return;
						}
						if($player->getGhostEnergy() < $player->getGhostEnergyCost($item->getId())){
							$player->sendMessage(str_replace(["&", "{currentEnergy}", "{needEnergy}"], ["§", $player->getGhostEnergy(), $player->getGhostEnergyCost($item->getId())], Loader::getConfiguration("messages")->get("ghost_not_enough_energy")));
							return;
						}
						$effect = new EffectInstance(Player::getEffectName('invisibility'), 30 * 10, 0);

						$player->setGhostEnergy($player->getGhostEnergy() - $player->getGhostEnergyCost($item->getId()));
						$player->addEffect($effect);
                        $player->sendMessage(str_replace(["&", "{effectName}", "{effectLevel}"], ["§", Translator::effectToStringByObject($effect), $effect->getAmplifier()], Loader::getConfiguration("messages")->get("ghost_give_effects")));

                        $item->setCount($item->getCount() - 1);
                        $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                        if(Factions::inFaction($player->getName())){
                        	foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
                           	 $online = Loader::getInstance()->getServer()->getPlayerExact($value);
                        	    if($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 250){
                           	     	$online->addEffect($effect);
									$online->sendMessage(str_replace(["&", "{playerName}", "{effectName}", "{effectLevel}"], ["§", $player->getName(), Translator::effectToStringByObject($effect), $effect->getAmplifier()], Loader::getConfiguration("messages")->get("ghost_global_give_effects")));
                            	}
                            }
                        }
					break;
					case ItemIds::MAGMA_CREAM:
						if(Factions::isSpawnRegion($player)){
							$event->cancel();
							return;
						}
						if($player->getGhostEnergy() < $player->getGhostEnergyCost($item->getId())){
							$player->sendMessage(str_replace(["&", "{currentEnergy}", "{needEnergy}"], ["§", $player->getGhostEnergy(), $player->getGhostEnergyCost($item->getId())], Loader::getConfiguration("messages")->get("ghost_not_enough_energy")));
							return;
						}
						$effect = new EffectInstance(Player::getEffectName('fire'), 50 * 50, 1);

						$player->setBardEnergy($player->getBardEnergy() - $player->getGhostEnergyCost($item->getId()));
						$player->addEffect($effect);
                        $player->sendMessage(str_replace(["&", "{effectName}", "{effectLevel}"], ["§", Translator::effectToStringByObject($effect), $effect->getAmplifier()], Loader::getConfiguration("messages")->get("ghost_give_effects")));

                        $item->setCount($item->getCount() - 1);
                        $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));
                        if(Factions::inFaction($player->getName())){
                        	foreach(Factions::getPlayers(Factions::getFaction($player->getName())) as $value){
                           	 $online = Loader::getInstance()->getServer()->getPlayerExact($value);
                        	    if($online instanceof Player && $online->getPosition()->distanceSquared($player->getPosition()) < 250){
                           	     	$online->addEffect($effect);
									$online->sendMessage(str_replace(["&", "{playerName}", "{effectName}", "{effectLevel}"], ["§", $player->getName(), Translator::effectToStringByObject($effect), $effect->getAmplifier()], Loader::getConfiguration("messages")->get("ghost_global_give_effects")));
                            	}
                            }
                        }
					break;
					case ItemIds::SPIDER_EYE:
						if(Factions::isSpawnRegion($player)){
							$event->cancel();
							return;
						}
						if($player->getGhostEnergy() < $player->getGhostEnergyCost($item->getId())){
							$player->sendMessage(str_replace(["&", "{currentEnergy}", "{needEnergy}"], ["§", $player->getGhostEnergy(), $player->getGhostEnergyCost($item->getId())], Loader::getConfiguration("messages")->get("ghost_not_enough_energy")));
							return;
						}
						$effect = new EffectInstance(Player::getEffectName('wither'), 20 * 7, 1);

						foreach(Loader::getInstance()->getServer()->getOnlinePlayers() as $online){
							if($online->getPosition()->distanceSquared($player) < 250){
							    $online->addEffect($effect);
                                $online->sendMessage(str_replace(["&", "{playerName}", "{effectName}", "{effectLevel}"], ["§", $player->getName(), Translator::effectToStringByObject($effect), $effect->getAmplifier()], Loader::getConfiguration("messages")->get("ghost_global_give_effects")));
							}
						}
                        $player->sendMessage(str_replace(["&", "{effectName}", "{effectLevel}"], ["§", Translator::effectToStringByObject($effect), $effect->getAmplifier()], Loader::getConfiguration("messages")->get("ghost_give_effects")));

                        $player->setBardEnergy($player->getBardEnergy() - $player->getBardEnergyCost($item->getId()));
						
						$item->setCount($item->getCount() - 1);
                        $player->getInventory()->setItemInHand($item->getCount() > 0 ? $item :  (new ItemFactory)->get(ItemIds::AIR));                
					break;
                }
			}
		}
	}
}

?>