<?php

namespace venity\item;

use pocketmine\block\Block;
use pocketmine\item\{ItemIds, ItemIdentifier};
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\entity\Location;
use pocketmine\entity\projectile\Throwable;

class EnderEye extends \pocketmine\item\Item {

    /**
     * EnderEye Constructor.
     * @param Int $meta
     */
    public function __construct(Int $meta = 0){
        $item = new ItemIdentifier(ItemIds::ENDER_EYE, $meta);
        parent::__construct($item, "Ender Eye");
    }

    /**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 64;
    }
}

?>