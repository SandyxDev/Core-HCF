<?php

namespace venity\item;

use pocketmine\entity\effect\Effect;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\item\Food;
use pocketmine\item\{ItemIds, ItemIdentifier};
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\entity\Location;
use pocketmine\entity\projectile\Throwable;

class GoldenAppleEnchanted extends GoldenApple {
	
	/**
	 * GoldenAppleEnchanted Constructor.
	 * @param Int $meta
	 */
	public function __construct(Int $meta = 0){
		$item = new ItemIdentifier(ItemIds::ENCHANTED_GOLDEN_APPLE, $meta);
		Food::__construct($item, "Enchanted Golden Apple");
	}
	
	/**
	 * @return Array
	 */
	public function getAdditionalEffects() : Array {
		return [
			new EffectInstance(Player::getEffectName('regeneration'), 600, 4),
			new EffectInstance(Effect::getEffect(Effect::ABSORPTION), 2400, 3),
			new EffectInstance(Player::getEffectName('resistance'), 6000),
			new EffectInstance(Player::getEffectName('fire'), 6000)
		];
	}
}

?>