<?php

namespace venity\item;

use venity\Loader;

use pocketmine\item\Potion;
use pocketmine\world\sound\LaunchSound;
use pocketmine\item\ItemUseResult;
use pocketmine\item\{ItemIds, ItemIdentifier};
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\entity\Location;
use pocketmine\entity\projectile\Throwable;
use pocketmine\entities\SplashPotion as SplashPotionEntity;
class SplashPotion extends \pocketmine\item\ProjectileItem {
	
	/**
	 * SplashPotion Constructor.
	 * @param Int $meta
	 */
	public function __construct($meta = 0){
		$item = new ItemIdentifier(ItemIds::SPLASH_POTION, $meta);
		parent::__construct($item, "Splash Potion");
	}
	
	/**
	 * @param Player $player
	 * @param Vector3 $directionVector
	 */
	public function onClickAir(Player $player, Vector3 $directionVector): ItemUseResult{
		return true;
	}
	/** 
	 * ni puta idea que retorna osea tipo un int @return int verga man xd 
	*/
	public function createEntity(Location $location, Player $thrower) : Throwable{
		return new SplashPotionEntity($location, $thrower);
	}

	
	/**
	 * @return Int
	 */
	public function getMaxStackSize() : Int {
		return 1;
	}
	
	/**
	 * @return String
	 */
	public function getProjectileEntityType() : String {
		return "SplashPotion";
	}
	
	/**
	 * @return float
	 */
	public function getThrowForce() : float {
        return 0.7;
	}
}

?>