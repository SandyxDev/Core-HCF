<?php

namespace venity\item;

use pocketmine\entity\effect\Effect;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\item\{ItemIds, ItemIdentifier};
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\entity\Location;
use pocketmine\entity\projectile\Throwable;

class GoldenApple extends \pocketmine\item\Food {
	
	/**
	 * GoldenApple Constructor.
	 * @param Int $meta
	 */
	public function __construct(Int $meta = 0){
		$item = new ItemIdentifier(ItemIds::GOLDEN_APPLE, $meta);
		parent::__construct($item, "Golden Apple");
	}
	
	/**
	 * @return bool
	 */
	public function requiresHunger() : bool {
		return false;
	}
	
	/**
	 * @return float
	 */
	public function getSaturationRestore() : float {
		return 9.6;
	}
	
	/**
	 * @return Int
	 */
	public function getFoodRestore() : Int {
		return 6;
	}
	
	/**
	 * @return Array
	 */
	public function getAdditionalEffects() : Array {
		return [
			new EffectInstance(Player::getEffectName('regeneration'), 100),
			new EffectInstance(Effect::getEffect(Effect::ABSORPTION), 2400),
		];
	}
}

?>