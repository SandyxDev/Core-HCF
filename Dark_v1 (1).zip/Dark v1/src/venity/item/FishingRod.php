<?php

namespace venity\item;

use venity\Loader;
use pocketmine\world\sound\LaunchSound;
use pocketmine\item\{ItemUseResult,ItemIds, ItemIdentifier};
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\entity\Location;
use pocketmine\entity\projectile\Throwable;
use pocketmine\entities\FishingHook as FishingHook;
class FishingRod extends \pocketmine\item\ProjectileItem {
	
	/**
	 * FishingRod Constructor.
	 * @param Int $meta
	 */
	public function __construct($meta = 0){
		$item = new ItemIdentifier(ItemIds::FISHING_ROD, $meta);
		parent::__construct($item, "Fishing Rod");
	}
	
	/**
	 * @param Player $player
	 * @param Vector3 $directionVector
	 */
	
	public function createEntity(Location $location, Player $thrower) : Throwable{
		return new FishingHook($location, $thrower);
	}

	public function onClickAir(Player $player, Vector3 $directionVector): ItemUseResult{
		return true;
	}
	
	/**
	 * @return Int
	 */
	public function getMaxStackSize() : Int {
		return 1;
	}
	
	/**
	 * @return String
	 */
	public function getProjectileEntityType() : String {
		return "Fishing Rod";
	}
	
	/**
	 * @return float
	 */
	public function getThrowForce() : float {
        return 2.1;
	}
}

?>