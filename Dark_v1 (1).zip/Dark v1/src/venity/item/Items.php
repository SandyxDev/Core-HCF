<?php

namespace venity\item;

use venity\item\specials\{Firework,
    SecondChance,
    RemoveEffect,
    StormBreaker,
    AntiTrapper,
    EggPorts,
    Strength,
    Resistance,
    Invisibility,
    PotionCounter,
    NinjaShear,
    LoggerBait,
    RageBrick,
    RareBrick,
    Berserk,
    Energy,
    Medkit,                        
    Cactus,
    PartnerPackages,
    ZombieBardItem
};

use venity\item\netherite\{Helmet, Chestplate, Leggings, Boots, Sword, Pickaxe};

use pocketmine\item\{Item, ItemFactory};

class Items {

	const NETHERITE_HELMET = 748, NETHERITE_CHESTPLATE = 749, NETHERITE_LEGGINGS = 750, NETHERITE_BOOTS = 751, NETHERITE_SWORD = 743, NETHERITE_PICKAXE = 745;
	
	/**
	 * @return void
	 */
	public static function init() : void {
		(new ItemFactory)->register(new FishingRod(), true);
		(new ItemFactory)->register(new SplashPotion(), true);
		(new ItemFactory)->register(new GoldenApple(), true);
		(new ItemFactory)->register(new GoldenAppleEnchanted(), true);
		(new ItemFactory)->register(new EnderEye(), true);

		(new ItemFactory)->register(new StormBreaker(), true);
		(new ItemFactory)->register(new SecondChance(), true);
		(new ItemFactory)->register(new AntiTrapper(), true);
		(new ItemFactory)->register(new EggPorts(), true);
		(new ItemFactory)->register(new Strength(), true);
		(new ItemFactory)->register(new Resistance(), true);
		(new ItemFactory)->register(new NinjaShear(), true);
		(new ItemFactory)->register(new Resistance(), true);
		(new ItemFactory)->register(new Strength(), true);
		(new ItemFactory)->register(new Invisibility(), true);
		(new ItemFactory)->register(new PotionCounter(), true);
		(new ItemFactory)->register(new Firework(), true);
        (new ItemFactory)->register(new Ragebrick(), true);
        (new ItemFactory)->register(new PartnerPackages(), true);
        (new ItemFactory)->register(new LoggerBait(), true);
        (new ItemFactory)->register(new Berserk(), true);
        (new ItemFactory)->register(new ZombieBardItem(), true);
        (new ItemFactory)->register(new Energy(), true);
        (new ItemFactory)->register(new Medkit(), true); 
	}

	/**
	 * @param Item $item
	 * @return Array[]
	 */
	public static function itemSerialize(Item $item) : Array {
		$data = $item->jsonSerialize();
		return $data;
	}

	/**
	 * @param Array $items
	 * @return Item
	 */
	public static function itemDeserialize(Array $items) : Item {
		$item = Item::jsonDeserialize($items);
		return $item;
	}
}

?>