<?php

namespace venity\item\specials;

use venity\Loader;
use venity\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\item\ItemIds;
class Energy extends Custom {
	
	const CUSTOM_ITEM = "CustomItem";
	
	/**
	 * Strength Constructor.
	 */
	public function __construct(){
		parent::__construct(ItemIds::GLOWSTONE_DUST, TE::YELLOW.TE::BOLD."Energy Dust", [TE::RESET."\n".TE::GRAY."Give yourself Speed 3 for 10 seconds".TE::GRAY."\n".TE::GRAY."and Strength 1 for 5 seconds".TE::GRAY."\n\n".TE::WHITE.TE::BOLD."Can be found in the".TE::GREEN." Item ".TE::WHITE."crate"]);
				$CompoundTag = CompoundTag::create(self::CUSTOM_ITEM);
		$this->setNamedTag($CompoundTag);
	}
	
	/**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 64;
    }
}

?>