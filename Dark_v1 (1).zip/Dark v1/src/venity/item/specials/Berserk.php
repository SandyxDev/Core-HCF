<?php

namespace venity\item\specials;

use venity\Loader;
use venity\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\item\ItemIds;
class Berserk extends Custom {
	
	const CUSTOM_ITEM = "CustomItem";
	
	/**
	 * Strength Constructor.
	 */
	public function __construct(){
		parent::__construct(ItemIds::REDSTONE,  TE::DARK_RED.TE::BOLD."Berserk Ability", [TE::RESET."\n".TE::GRAY."Give yourself Strength 3".TE::GRAY."\n".TE::GRAY."and Resistance 2".TE::GRAY."\n\n".TE::WHITE.TE::BOLD."Can be found in the".TE::GREEN." Item ".TE::WHITE."crate"]);
				$CompoundTag = CompoundTag::create(self::CUSTOM_ITEM);
		$this->setNamedTag($CompoundTag);
	}
	
	/**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 64;
    }
}

?>