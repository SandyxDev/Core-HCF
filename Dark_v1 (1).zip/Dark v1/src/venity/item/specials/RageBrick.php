<?php

namespace venity\item\specials;

use venity\Loader;
use venity\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\item\ItemIds;
class Ragebrick extends Custom {
	
	const CUSTOM_ITEM = "CustomItem";
	
	/**
	 * Strength Constructor.
	 */
	public function __construct(){
		parent::__construct(ItemIds::NETHERBRICK, TE::GOLD.TE::BOLD."RageBrick", [TE::RESET."\n".TE::GRAY."Give yourself Strength 2".TE::GRAY."\n".TE::GRAY."for 5 seconds".TE::GRAY."\n\n".TE::WHITE.TE::BOLD."Can be found in the".TE::GREEN." Item ".TE::WHITE."crate"]);
				$CompoundTag = CompoundTag::create(self::CUSTOM_ITEM);
		$this->setNamedTag($CompoundTag);
	}
	
	/**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 64;
    }
}

?>