<?php

namespace venity\item\specials;

use venity\Loader;
use venity\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\item\ItemIds;
class StormBreaker extends Custom {
	
	const CUSTOM_ITEM = "CustomItem";
	
	const USES_LEFT = "Uses left";
	
	/**
	 * StormBreaker Constructor.
	 * @param Int $usesLeft
	 */
	public function __construct(Int $usesLeft = 5){
        $CompoundTag = CompoundTag::create(self::CUSTOM_ITEM);
		$this->setNamedTag($CompoundTag);
		$this->getNamedTag(self::CUSTOM_ITEM)->setInt(self::USES_LEFT, $usesLeft);
        $this->setLore( [TE::RESET."\n".TE::GRAY."When you hit a player with this there".TE::GRAY."\n".TE::GRAY."will come off".TE::GRAY."\n\n".TE::WHITE.TE::BOLD."Can be found in the".TE::GREEN." Item ".TE::WHITE."crate"."\n\n".TE::YELLOW."Uses Left: ".TE::GOLD.$usesLeft]);
		parent::__construct(ItemIds::GOLDEN_AXE , TE::GOLD.TE::BOLD."StormBreaker", [TE::RESET."\n".TE::GRAY."When you hit a player with this there".TE::GRAY."\n".TE::GRAY."will come off".TE::GRAY."\n\n".TE::WHITE.TE::BOLD."Can be found in the".TE::GREEN." Item ".TE::WHITE."crate"."\n\n".TE::YELLOW."Uses Left: ".TE::GOLD.$usesLeft]);
	}
	
	/**
	 * @param Player $player
	 * @return void
	 */
	public function reduceUses(Player $player) : void {
		$nbt = $this->getNamedTag(self::CUSTOM_ITEM)->getInt(self::USES_LEFT);
		if($nbt > 0){
			$nbt--;
			if($nbt === 0){
				$player->getInventory()->setItemInHand(self::get(self::AIR));
			}else{
				$this->setNamedTag(self::CUSTOM_ITEM)->setInt(self::USES_LEFT, $nbt);
				$this->setLore([TE::RESET."\n".TE::GRAY."When you hit a player with this there".TE::GRAY."\n".TE::GRAY."will come off".TE::GRAY."\n\n".TE::WHITE.TE::BOLD."Can be found in the".TE::GREEN." Item ".TE::WHITE."crate"."\n\n".TE::YELLOW."Uses Left: ".TE::GOLD.$nbt]);
				$player->getInventory()->setItemInHand($this);
			}
		}
	}
	
	/**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 1;
    }
}

?>