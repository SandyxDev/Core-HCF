<?php

namespace venity\item\specials;

use venity\Loader;
use venity\player\Player;

use pocketmine\utils\TextFormat as TE;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\item\ItemIds;
class Cactus extends Custom {
	
	const CUSTOM_ITEM = "CustomItem";
	
	/**
	 * Resistance Constructor.
	 */
	public function __construct(){
		parent::__construct(ItemIds::CACTUS, "Cactus", [TE::GREEN.TE::BOLD."RARE ITEM".TE::RESET."\n\n".TE::GRAY."You can get Strength and Resistance 4 by yourself (4 seconds) "]);
				$CompoundTag = CompoundTag::create(self::CUSTOM_ITEM);
		$this->setNamedTag($CompoundTag);
	}
	
	/**
     * @return Int
     */
    public function getMaxStackSize() : Int {
        return 64;
    }
}

?>