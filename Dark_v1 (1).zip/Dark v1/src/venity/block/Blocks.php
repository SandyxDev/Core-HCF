<?php

namespace venity\block;

use venity\block\redstone\{
    PressurePlate,
};
use pocketmine\block\{Block, BlockFactory};
use pocketmine\block\{BlockIdentifier, BlockLegacyIds, BlockBreakInfo, BlockToolType};
class Blocks {

    /**
     * @return void
     */
    public static function init() : void {
        (new BlockFactory)->register(new MonsterSpawner(), true);
        (new BlockFactory)->register(new EndPortalFrame(), true);
    }
}

?>