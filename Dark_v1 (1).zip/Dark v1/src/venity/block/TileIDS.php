<?php

namespace venity\block;

interface TileIDS{
    
 const DISPENSER = "Dispenser";
}