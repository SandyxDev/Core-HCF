<?php

namespace venity\enchantments\type;

use pocketmine\utils\TextFormat as TE;

use venity\enchantments\CustomEnchantment;

use pocketmine\entity\effect\{Effect, EffectInstance};

use pocketmine\item\enchantment\Enchantment;

class Invisibility extends CustomEnchantment {

    /**
     * Invisibility Constructor.
     */
    public function __construct(){
        parent::__construct($this->getId(), $this->getName(), self::RARITY_COMMON, self::SLOT_ARMOR, self::SLOT_NONE, 1);
    }

    /**
     * @return Int
     */
    public function getId() : Int {
        return 39;
    }

    /**
     * @return String
     */
    public function getName() : String {
        return "Invisibility";
    }
    
    /**
     * @return String
     */
    public function getNameWithFormat() : String {
    	return TE::RESET.TE::DARK_GRAY."Invisibility I";
    }

    /**
     * @return EffectInstance
     */
    public function getEffectsByEnchantment() : EffectInstance {
        return new EffectInstance(Player::getEffectName('invisibility'), 60, ($this->getMaxLevel() - 1));
    }
    
    /**
     * @return Int
     */
    public function getEnchantmentPrice() : Int {
    	return 15000;
   }
}

?>