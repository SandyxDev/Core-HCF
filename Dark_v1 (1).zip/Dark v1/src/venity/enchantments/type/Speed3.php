<?php

namespace venity\enchantments\type;

use pocketmine\utils\TextFormat as TE;

use venity\enchantments\CustomEnchantment;

use pocketmine\entity\effect\{Effect, EffectInstance};

use pocketmine\item\enchantment\Enchantment;

class Speed extends CustomEnchantment {

    /**

     * SpeedEnchantment Constructor.

     */

    public function __construct(){

        parent::__construct($this->getId(), $this->getName(), self::RARITY_COMMON, self::SLOT_ARMOR, self::SLOT_NONE, 3);

    }

    /**

     * @return Int

     */

    public function getId() : Int {

        return 37;

    }

    /**

     * @return String

     */

    public function getName() : String {

        return "Speed";

    }

    

    /**

     * @return String

     */

    public function getNameWithFormat() : String {

    	return TE::RESET.TE::AQUA."Speed 3";

    }

    /**

     * @return EffectInstance

     */

    public function getEffectsByEnchantment() : EffectInstance {

        return new EffectInstance(Player::getEffectName('speed'), 60, ($this->getMaxLevel() - 1));

    }

    

    /**

     * @return Int

     */

    public function getEnchantmentPrice() : Int {

    	return 0;

   }

}

?>